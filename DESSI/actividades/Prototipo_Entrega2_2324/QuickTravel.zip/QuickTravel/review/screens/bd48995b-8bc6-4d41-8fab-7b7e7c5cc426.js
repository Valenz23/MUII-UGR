var content='<div class="ui-page " deviceName="androidphone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1705362672774.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-bd48995b-8bc6-4d41-8fab-7b7e7c5cc426" class="screen growth-vertical devMobile devAndroid android-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="localizacion - DATOS_normal"width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/bd48995b-8bc6-4d41-8fab-7b7e7c5cc426-1705362672774.css" />\
      <div class="freeLayout">\
      <div id="s-Image_1" class="image firer ie-background commentable non-processed" customid="fondo"   datasizewidth="360.0px" datasizeheight="640.0px" dataX="-0.0" dataY="0.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/d96c693e-b289-413e-b713-b20ad7db98f5.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Hotspot_5" class="imagemap firer click ie-background commentable non-processed" customid="B - a&ntilde;adir ruta"   datasizewidth="176.0px" datasizeheight="56.0px" dataX="4.0" dataY="578.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_6" class="imagemap firer click ie-background commentable non-processed" customid="B - sug cambios"   datasizewidth="172.0px" datasizeheight="51.9px" dataX="188.0" dataY="583.1"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_7" class="imagemap firer click ie-background commentable non-processed" customid="B - pesta&ntilde;a rese&ntilde;a"   datasizewidth="180.0px" datasizeheight="54.9px" dataX="180.0" dataY="87.2"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_8" class="imagemap firer click ie-background commentable non-processed" customid="B - atras"   datasizewidth="58.0px" datasizeheight="69.0px" dataX="11.0" dataY="11.6"  >\
        <div class="clickableSpot"></div>\
      </div>\
\
      <div id="s-Image" class="image firer ie-background commentable hidden non-processed" customid="popup - sug cambios"   datasizewidth="340.0px" datasizeheight="407.0px" dataX="10.0" dataY="159.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/5928c628-c070-4049-bc0e-aa6e741f5d25.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Hotspot_1" class="imagemap firer click ie-background commentable non-processed" customid="b - conf cambios"   datasizewidth="147.0px" datasizeheight="56.0px" dataX="33.0" dataY="496.8"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_2" class="imagemap firer click ie-background commentable non-processed" customid="b - cancelar cambios"   datasizewidth="147.0px" datasizeheight="56.0px" dataX="192.0" dataY="497.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
\
      <div id="s-Image_2" class="image firer ie-background commentable hidden non-processed" customid="popup - mensaje enviado"   datasizewidth="292.0px" datasizeheight="196.0px" dataX="34.0" dataY="258.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/189a8202-f50e-4589-a7d9-ac572bbacd61.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_3" class="image firer ie-background commentable hidden non-processed" customid="popup - mensaje descartado"   datasizewidth="292.0px" datasizeheight="196.0px" dataX="34.0" dataY="258.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/9adb32fa-d963-432a-9a26-ca0835a7fd82.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_4" class="image firer ie-background commentable hidden non-processed" customid="popup - addRuta"   datasizewidth="292.0px" datasizeheight="196.0px" dataX="34.0" dataY="170.5"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/d1f5c895-cd6f-4b5b-a593-d82a02ded26a.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Hotspot_3" class="imagemap firer click ie-background commentable non-processed" customid="conf"   datasizewidth="229.0px" datasizeheight="46.0px" dataX="69.0" dataY="400.5"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_4" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 4"   datasizewidth="195.0px" datasizeheight="43.0px" dataX="92.0" dataY="320.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;