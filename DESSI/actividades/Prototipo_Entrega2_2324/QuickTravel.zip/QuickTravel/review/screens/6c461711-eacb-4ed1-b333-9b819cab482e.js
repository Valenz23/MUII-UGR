var content='<div class="ui-page " deviceName="androidphone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1705362672774.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-6c461711-eacb-4ed1-b333-9b819cab482e" class="screen growth-vertical devMobile devAndroid android-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="localizacion - RESE&Ntilde;AS_normal"width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/6c461711-eacb-4ed1-b333-9b819cab482e-1705362672774.css" />\
      <div class="freeLayout">\
      <div id="s-Image_1" class="image firer ie-background commentable non-processed" customid="fondo"   datasizewidth="360.0px" datasizeheight="640.0px" dataX="-0.0" dataY="0.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/32d99c42-396a-426c-912e-53d6d9184ae2.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Hotspot_5" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 5"   datasizewidth="352.0px" datasizeheight="56.0px" dataX="-0.0" dataY="580.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
\
      <div id="s-Image" class="image firer ie-background commentable hidden non-processed" customid="popup - add rese&ntilde;a"   datasizewidth="309.0px" datasizeheight="378.0px" dataX="28.0" dataY="174.4"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/162ef2f7-b1d5-4b62-9736-4d50246527fa.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Hotspot_7" class="imagemap firer click ie-background commentable non-processed" customid="pesta&ntilde;a datos"   datasizewidth="180.0px" datasizeheight="54.9px" dataX="-0.0" dataY="92.1"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_8" class="imagemap firer click ie-background commentable non-processed" customid="atras"   datasizewidth="57.0px" datasizeheight="54.0px" dataX="21.0" dataY="28.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_1" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 1"   datasizewidth="126.5px" datasizeheight="51.7px" dataX="49.5" dataY="486.1"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_2" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 1"   datasizewidth="127.5px" datasizeheight="51.7px" dataX="198.0" dataY="486.1"  >\
        <div class="clickableSpot"></div>\
      </div>\
\
      <div id="s-Image_2" class="image firer ie-background commentable hidden non-processed" customid="popup - mensaje enviado"   datasizewidth="292.0px" datasizeheight="196.0px" dataX="34.0" dataY="258.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/189a8202-f50e-4589-a7d9-ac572bbacd61.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_3" class="image firer ie-background commentable hidden non-processed" customid="popup - mensaje descartado"   datasizewidth="292.0px" datasizeheight="196.0px" dataX="34.0" dataY="258.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/9adb32fa-d963-432a-9a26-ca0835a7fd82.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Hotspot_3" class="imagemap firer click ie-background commentable non-processed" customid="conf"   datasizewidth="229.0px" datasizeheight="46.0px" dataX="69.0" dataY="400.5"  >\
        <div class="clickableSpot"></div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;