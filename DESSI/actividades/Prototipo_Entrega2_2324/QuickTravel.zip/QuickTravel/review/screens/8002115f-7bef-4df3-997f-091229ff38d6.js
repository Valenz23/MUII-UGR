var content='<div class="ui-page " deviceName="androidphone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1705362672774.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-8002115f-7bef-4df3-997f-091229ff38d6" class="screen growth-vertical devMobile devAndroid android-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="inicio FILTRO"width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/8002115f-7bef-4df3-997f-091229ff38d6-1705362672774.css" />\
      <div class="freeLayout">\
      <div id="s-Image_1" class="image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="360.0px" datasizeheight="640.0px" dataX="-0.0" dataY="0.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/e90cc403-66c7-4c5d-9f79-932bd2195306.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Hotspot_1" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 1"   datasizewidth="79.0px" datasizeheight="89.4px" dataX="272.0" dataY="11.6"  >\
        <div class="clickableSpot"></div>\
      </div>\
\
      <div id="s-Image" class="image firer ie-background commentable hidden non-processed" customid="Image"   datasizewidth="148.0px" datasizeheight="173.0px" dataX="212.0" dataY="96.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/f214b2f9-bc94-48c3-8f97-4eb2d6fe9987.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Hotspot_2" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 2"   datasizewidth="196.0px" datasizeheight="157.0px" dataX="11.0" dataY="115.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_3" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 3"   datasizewidth="148.0px" datasizeheight="40.0px" dataX="212.0" dataY="125.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_4" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 4"   datasizewidth="151.0px" datasizeheight="34.8px" dataX="212.0" dataY="163.1"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_5" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 5"   datasizewidth="68.0px" datasizeheight="64.0px" dataX="20.0" dataY="542.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_6" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 6"   datasizewidth="48.0px" datasizeheight="77.0px" dataX="100.0" dataY="407.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_7" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 1"   datasizewidth="79.0px" datasizeheight="89.4px" dataX="272.0" dataY="11.6"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_8" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 8"   datasizewidth="148.5px" datasizeheight="42.3px" dataX="211.5" dataY="193.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;