(function(window, undefined) {

  var jimLinks = {
    "4e39cbc2-ef25-4ce0-80c4-17b08f574a9c" : {
      "Hotspot_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "e4a7ac8c-d008-465a-a5ba-dad5ef0f4d6d" : {
      "Hotspot_3" : [
        "d639823a-add8-4ab5-8c0f-1f460b7e886c"
      ],
      "Hotspot_4" : [
        "1babc1b0-ad6d-49e7-a540-677bde277f9b"
      ]
    },
    "7699c6f4-e99e-4163-8b56-5383848d89df" : {
      "Hotspot_1" : [
        "e4a7ac8c-d008-465a-a5ba-dad5ef0f4d6d"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Hotspot_1" : [
        "7699c6f4-e99e-4163-8b56-5383848d89df"
      ],
      "Hotspot_2" : [
        "e4a7ac8c-d008-465a-a5ba-dad5ef0f4d6d"
      ],
      "Button_1" : [
        "4e39cbc2-ef25-4ce0-80c4-17b08f574a9c"
      ]
    },
    "d471e6be-722b-4289-a4a6-22a129a65862" : {
      "Hotspot_1" : [
        "4e39cbc2-ef25-4ce0-80c4-17b08f574a9c"
      ],
      "Hotspot_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "d639823a-add8-4ab5-8c0f-1f460b7e886c" : {
      "Hotspot_1" : [
        "d639823a-add8-4ab5-8c0f-1f460b7e886c"
      ],
      "Hotspot_2" : [
        "e4a7ac8c-d008-465a-a5ba-dad5ef0f4d6d"
      ]
    },
    "1babc1b0-ad6d-49e7-a540-677bde277f9b" : {
      "Hotspot_1" : [
        "1babc1b0-ad6d-49e7-a540-677bde277f9b"
      ],
      "Hotspot_2" : [
        "e4a7ac8c-d008-465a-a5ba-dad5ef0f4d6d"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);