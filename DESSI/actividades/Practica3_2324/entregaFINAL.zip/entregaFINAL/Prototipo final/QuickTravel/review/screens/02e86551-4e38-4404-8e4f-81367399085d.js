var content='<div class="ui-page " deviceName="androidphone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1705362672774.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-02e86551-4e38-4404-8e4f-81367399085d" class="screen growth-vertical devMobile devAndroid android-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="crear ruta 1"width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/02e86551-4e38-4404-8e4f-81367399085d-1705362672774.css" />\
      <div class="freeLayout">\
      <div id="s-Image" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="360.0px" datasizeheight="640.0px" dataX="-0.0" dataY="0.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/aca31b81-9ca3-4de3-b81e-59a8aea3e63f.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Hotspot_1" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 1"   datasizewidth="61.0px" datasizeheight="57.0px" dataX="16.0" dataY="18.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
\
      <div id="s-Image_1" class="image firer ie-background commentable hidden non-processed" customid="Image"   datasizewidth="208.0px" datasizeheight="211.0px" dataX="81.5" dataY="290.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/9dd17a31-46d5-4b90-826d-f005e70dbdf8.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Hotspot_2" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 2"   datasizewidth="65.5px" datasizeheight="55.8px" dataX="16.0" dataY="584.2"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_3" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 3"   datasizewidth="157.0px" datasizeheight="48.0px" dataX="112.0" dataY="448.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_4" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 4"   datasizewidth="53.0px" datasizeheight="52.0px" dataX="289.5" dataY="580.3"  >\
        <div class="clickableSpot"></div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;