var content='<div class="ui-page " deviceName="androidphone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1705362672774.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-b85dbafa-dce5-4914-9bee-803e3cc20476" class="screen growth-vertical devMobile devAndroid android-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="crear ruta 3"width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/b85dbafa-dce5-4914-9bee-803e3cc20476-1705362672774.css" />\
      <div class="freeLayout">\
      <div id="s-Image" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="360.0px" datasizeheight="640.0px" dataX="0.0" dataY="0.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/af4fb9fd-96bd-487d-bef9-4598cf06c8b4.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_1" class="image firer ie-background commentable hidden non-processed" customid="popu eliminar"   datasizewidth="208.0px" datasizeheight="211.0px" dataX="91.5" dataY="220.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/9dd17a31-46d5-4b90-826d-f005e70dbdf8.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_2" class="image firer ie-background commentable hidden non-processed" customid="popup nombrar la ruta"   datasizewidth="325.0px" datasizeheight="331.0px" dataX="17.5" dataY="188.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/650e3d21-8a78-459c-9250-028a9f8482f6.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_3" class="image firer ie-background commentable hidden non-processed" customid="poppup ruta guardada"   datasizewidth="208.0px" datasizeheight="211.0px" dataX="91.5" dataY="220.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/1df5d646-7797-41a7-94e8-07bbc764351a.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Hotspot_1" class="imagemap firer click ie-background commentable non-processed" customid="conf"   datasizewidth="157.0px" datasizeheight="48.0px" dataX="117.0" dataY="383.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_2" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 2"   datasizewidth="65.5px" datasizeheight="55.8px" dataX="16.0" dataY="568.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_3" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 1"   datasizewidth="64.0px" datasizeheight="70.0px" dataX="8.0" dataY="16.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_4" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 4"   datasizewidth="73.0px" datasizeheight="79.0px" dataX="269.0" dataY="109.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_5" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 5"   datasizewidth="73.0px" datasizeheight="60.4px" dataX="269.0" dataY="568.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_6" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 6"   datasizewidth="148.5px" datasizeheight="58.0px" dataX="31.5" dataY="455.5"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_7" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 7"   datasizewidth="146.0px" datasizeheight="58.0px" dataX="188.0" dataY="455.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;