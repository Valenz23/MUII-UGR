var content='<div class="ui-page " deviceName="androidphone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1707248953625.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-02e86551-4e38-4404-8e4f-81367399085d" class="screen growth-vertical devMobile devAndroid android-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="crear ruta 1"width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/02e86551-4e38-4404-8e4f-81367399085d-1707248953625.css" />\
      <div class="freeLayout">\
      <div id="s-Group_3" class="group firer ie-background commentable non-processed" customid="Siguiente" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_3" class="rectangle manualfit firer commentable non-processed" customid="BG - optional"   datasizewidth="360.0px" datasizeheight="68.0px" datasizewidthpx="360.00000000000017" datasizeheightpx="68.0" dataX="0.0" dataY="572.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_3_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_3" class="path firer ie-background commentable non-processed" customid="Line 1"   datasizewidth="362.0px" datasizeheight="3.0px" dataX="-0.5" dataY="571.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="361.0005798339844" height="2.2036337852478027" viewBox="-0.5002822875971162 571.0000001192097 361.0005798339844 2.2036337852478027" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_3-02e86" d="M2.8421709430404007E-13 572.0000000000001 L360.00000000000057 572.2036338912174 "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_3-02e86" fill="none" stroke-width="1.0" stroke="#3F51B5" stroke-linecap="butt"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_4" class="path firer commentable non-processed" customid="Chevron Rigth"   datasizewidth="24.4px" datasizeheight="39.5px" dataX="325.6" dataY="586.2"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="24.40999984741211" height="39.530364990234375" viewBox="325.5900001525881 586.2348175303109 24.40999984741211 39.530364990234375" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_4-02e86" d="M330.2348175303106 586.2348175303109 L325.5900001525881 590.8796349080334 L340.6774225197906 606.0000000000003 L325.5900001525881 621.1203650919673 L330.2348175303106 625.7651824696898 L350.0000000000002 606.0000000000003 L330.2348175303106 586.2348175303109 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_4-02e86" fill="#3F51B5" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_5" class="richtext manualfit firer ie-background commentable non-processed" customid="Siguiente"   datasizewidth="170.9px" datasizeheight="68.0px" dataX="189.1" dataY="572.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_5_0">Siguiente &nbsp; &nbsp;</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Hotspot_1" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 2"   datasizewidth="180.0px" datasizeheight="68.0px" dataX="180.0" dataY="572.0"  >\
          <div class="clickableSpot"></div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_4" class="group firer ie-background commentable non-processed" customid="area" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Image_1" class="image lockV firer ie-background commentable non-processed" customid="Map Image"   datasizewidth="300.0px" datasizeheight="286.8px" dataX="30.0" dataY="264.7" aspectRatio="0.95562315"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="./images/4315a98a-acd9-4688-b7ac-669c4bcf8f7c.png" />\
          	</div>\
          </div>\
        </div>\
\
        <div id="s-Path_129" class="path firer commentable non-processed" customid="Location On"   datasizewidth="28.0px" datasizeheight="40.0px" dataX="173.0" dataY="368.1"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="28.0" height="40.0" viewBox="173.0 368.1066609216785 28.0 40.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_129-02e86" d="M187.0 368.1066609216785 C179.26000022888184 368.1066609216785 173.0 374.36666115056033 173.0 382.1066609216785 C173.0 392.6066609216785 187.0 408.1066609216785 187.0 408.1066609216785 C187.0 408.1066609216785 201.0 392.6066609216785 201.0 382.1066609216785 C201.0 374.36666115056033 194.73999977111816 368.1066609216785 187.0 368.1066609216785 Z M187.0 387.1066609216785 C184.24000000953674 387.1066609216785 182.0 384.86666091214175 182.0 382.1066609216785 C182.0 379.34666093121524 184.24000000953674 377.1066609216785 187.0 377.1066609216785 C189.75999999046326 377.1066609216785 192.0 379.34666093121524 192.0 382.1066609216785 C192.0 384.86666091214175 189.75999999046326 387.1066609216785 187.0 387.1066609216785 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_129-02e86" fill="#F4115E" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Input_1" class="text firer commentable non-processed" customid="Input 1"  datasizewidth="300.0px" datasizeheight="45.0px" dataX="30.0" dataY="197.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Mi punto de origen"/></div></div>  </div></div></div>\
        <div id="s-Path_258" class="path firer commentable non-processed" customid="Location Fixed"   datasizewidth="33.7px" datasizeheight="33.7px" dataX="284.3" dataY="202.6"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="33.7470703125" height="33.7470703125" viewBox="284.25292968750017 202.62646484375082 33.7470703125 33.7470703125" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_258-02e86" d="M301.12646484374994 213.3641690340915 C297.7364181765694 213.3641690340915 294.99063387784093 216.10995333281994 294.99063387784093 219.50000000000048 C294.99063387784093 222.89004666718102 297.7364181765694 225.63583096590946 301.12646484374994 225.63583096590946 C304.5165115109305 225.63583096590946 307.26229580965895 222.89004666718102 307.26229580965895 219.50000000000048 C307.26229580965895 216.10995333281994 304.5165115109305 213.3641690340915 301.12646484374994 213.3641690340915 Z M314.8400464088823 217.96604225852323 C314.1344258350024 211.56943835953146 309.057025752771 206.49203832301555 302.66042185377916 205.78641770342017 L302.66042185377916 202.62646484375082 L299.59250637082465 202.62646484375082 L299.59250637082465 205.78641770342017 C293.19590320328086 206.49203832301555 288.1185031667649 211.56943835953146 287.41288254716954 217.96604225852323 L284.25292968750017 217.96604225852323 L284.25292968750017 221.03395774147774 L287.41288254716954 221.03395774147774 C288.1185031210494 227.4305616404695 293.19590320328086 232.50796167698542 299.5925071022727 233.2135822965808 L299.5925071022727 236.37353515625014 L302.6604225852272 236.37353515625014 L302.6604225852272 233.2135822965808 C309.057026484219 232.5079617227009 314.13442652073496 227.4305616404695 314.84004714033034 221.03395774147774 L317.9999999999997 221.03395774147774 L317.9999999999997 217.96604225852323 L314.84004714033034 217.96604225852323 Z M301.12646484374994 230.23770419034116 C295.1900485597805 230.23770419034116 290.3887606534092 225.4364162839699 290.3887606534092 219.50000000000048 C290.3887606534092 213.56358371603108 295.1900485597805 208.7622958096598 301.12646484374994 208.7622958096598 C307.0628811277194 208.7622958096598 311.8641690340907 213.56358371603108 311.8641690340907 219.50000000000048 C311.8641690340907 225.4364162839699 307.0628811277194 230.23770419034116 301.12646484374994 230.23770419034116 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_258-02e86" fill="#3F51B5" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_6" class="richtext autofit firer ie-background commentable non-processed" customid="Seleccione su punto de or"   datasizewidth="208.5px" datasizeheight="68.0px" dataX="75.7" dataY="109.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_6_0">Seleccione su <br />punto de origen</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_2" class="group firer ie-background commentable hidden non-processed" customid="popup eliminar" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 5"   datasizewidth="275.0px" datasizeheight="246.0px" datasizewidthpx="275.00000000000006" datasizeheightpx="245.99999999999994" dataX="42.5" dataY="177.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_2_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_2" class="richtext manualfit firer click commentable non-processed" customid="No"   datasizewidth="139.8px" datasizeheight="63.8px" dataX="177.7" dataY="359.2" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_2_0">No</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_3" class="richtext manualfit firer ie-background commentable non-processed" customid="&iquest;Desea eliminar la ruta?"   datasizewidth="275.0px" datasizeheight="185.5px" dataX="42.5" dataY="177.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_3_0">&iquest;Desea eliminar la ruta?</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_4" class="richtext manualfit firer click commentable non-processed" customid="Si"   datasizewidth="139.5px" datasizeheight="63.5px" dataX="42.5" dataY="359.2" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_4_0">Si</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="top" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="BG - optional"   datasizewidth="360.0px" datasizeheight="69.0px" datasizewidthpx="360.00000000000045" datasizeheightpx="68.99999999999997" dataX="-0.0" dataY="-0.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_1_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_1" class="path firer commentable non-processed" customid="Account_circle"   datasizewidth="50.0px" datasizeheight="50.0px" dataX="300.0" dataY="10.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="50.0" height="50.0" viewBox="300.0000000000002 9.999999999999572 50.0 50.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_1-02e86" d="M325.0000000000002 9.999999999999572 C311.20000004768394 9.999999999999572 300.0000000000002 21.200000047683286 300.0000000000002 34.99999999999957 C300.0000000000002 48.79999995231585 311.20000004768394 59.99999999999957 325.0000000000002 59.99999999999957 C338.7999999523165 59.99999999999957 350.0000000000002 48.79999995231585 350.0000000000002 34.99999999999957 C350.0000000000002 21.200000047683286 338.8000011444094 9.999999999999572 325.0000000000002 9.999999999999572 Z M325.0000000000002 17.49999999999957 C329.1499999165537 17.49999999999957 332.5000000000002 20.850000083446073 332.5000000000002 24.999999999999567 C332.5000000000002 29.149999916553064 329.1499999165537 32.49999999999957 325.0000000000002 32.49999999999957 C320.85000008344673 32.49999999999957 317.5000000000002 29.149999916553064 317.5000000000002 24.999999999999567 C317.5000000000002 20.850000083446073 320.85000008344673 17.49999999999957 325.0000000000002 17.49999999999957 Z M325.0000000000002 52.99999952316241 C318.7500000000002 52.99999952316241 313.2249999046328 49.79999959468798 310.0000000000002 44.949999451636835 C310.07499999832385 39.97499942779498 320.0000000000002 37.24999964237169 325.0000000000002 37.24999964237169 C329.9750000238421 37.24999964237169 339.92499947547935 39.9749997258182 340.0000000000002 44.949999451636835 C336.77500009536766 49.79999959468798 331.2500000000002 52.99999952316241 325.0000000000002 52.99999952316241 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-02e86" fill="#EFEFEF" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_1" class="richtext manualfit firer ie-background commentable non-processed" customid="Crear ruta"   datasizewidth="240.0px" datasizeheight="69.0px" dataX="60.0" dataY="-0.5" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_1_0">Crear ruta</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_2" class="path firer commentable non-processed" customid="Home"   datasizewidth="50.0px" datasizeheight="48.0px" dataX="10.0" dataY="10.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="50.0" height="48.0" viewBox="10.0 10.00000000000017 50.0 48.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_2-02e86" d="M30.0 58.00000000000017 L30.0 41.05882352941194 L40.0 41.05882352941194 L40.0 58.00000000000017 L52.5 58.00000000000017 L52.5 35.41176470588253 L60.0 35.41176470588253 L35.0 10.00000000000017 L10.0 35.41176470588253 L17.5 35.41176470588253 L17.5 58.00000000000017 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-02e86" fill="#EFEFEF" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Hotspot_3" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 2"   datasizewidth="71.0px" datasizeheight="69.0px" dataX="-0.0" dataY="0.0"  >\
          <div class="clickableSpot"></div>\
        </div>\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;