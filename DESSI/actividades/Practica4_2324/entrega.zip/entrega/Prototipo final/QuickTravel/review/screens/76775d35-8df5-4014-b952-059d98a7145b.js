var content='<div class="ui-page " deviceName="androidphone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1707248953625.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-76775d35-8df5-4014-b952-059d98a7145b" class="screen growth-vertical devMobile devAndroid android-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="crear ruta 2"width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/76775d35-8df5-4014-b952-059d98a7145b-1707248953625.css" />\
      <div class="freeLayout">\
      <div id="s-Group_4" class="group firer ie-background commentable non-processed" customid="bottom bar" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_4" class="rectangle manualfit firer commentable non-processed" customid="BG - optional"   datasizewidth="360.0px" datasizeheight="68.0px" datasizewidthpx="360.00000000000017" datasizeheightpx="68.0" dataX="0.0" dataY="572.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_4_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_5" class="path firer ie-background commentable non-processed" customid="Line 1"   datasizewidth="362.0px" datasizeheight="3.0px" dataX="-0.5" dataY="571.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="361.0005798339844" height="2.2036337852478027" viewBox="-0.5002822875971162 571.0000001192097 361.0005798339844 2.2036337852478027" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_5-76775" d="M2.8421709430404007E-13 572.0000000000001 L360.00000000000057 572.2036338912174 "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_5-76775" fill="none" stroke-width="1.0" stroke="#3F51B5" stroke-linecap="butt"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Group_6" class="group firer ie-background commentable non-processed" customid="Anterior" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Paragraph_7" class="richtext manualfit firer ie-background commentable non-processed" customid="Anterior"   datasizewidth="170.9px" datasizeheight="68.0px" dataX="9.1" dataY="571.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_7_0"> &nbsp; Anterior</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Path_7" class="path firer commentable non-processed" customid="Chevron Left"   datasizewidth="24.4px" datasizeheight="39.5px" dataX="10.0" dataY="584.7"  >\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg xmlns="http://www.w3.org/2000/svg" width="24.40999984741211" height="39.530364990234375" viewBox="9.99999999999983 584.734817724732 24.40999984741211 39.530364990234375" preserveAspectRatio="none">\
              	  <g>\
              	    <defs>\
              	      <path id="s-Path_7-76775" d="M34.40999960730093 589.3796350567654 L29.76518227526759 584.734817724732 L9.99999999999983 604.5 L29.76518227526759 624.265182275268 L34.409999999999826 619.6203645505357 L19.322577388507167 604.5 L34.40999960730093 589.3796350567654 Z "></path>\
              	    </defs>\
              	    <g style="mix-blend-mode:normal">\
              	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_7-76775" fill="#3F51B5" fill-opacity="1.0"></use>\
              	    </g>\
              	  </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
          <div id="s-Hotspot_4" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 2"   datasizewidth="180.0px" datasizeheight="68.0px" dataX="-0.0" dataY="572.0"  >\
            <div class="clickableSpot"></div>\
          </div>\
        </div>\
\
\
        <div id="s-Group_5" class="group firer ie-background commentable non-processed" customid="siguiente" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Path_4" class="path firer commentable non-processed" customid="Chevron Rigth"   datasizewidth="24.4px" datasizeheight="39.5px" dataX="325.6" dataY="586.2"  >\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg xmlns="http://www.w3.org/2000/svg" width="24.40999984741211" height="39.530364990234375" viewBox="325.59000015258744 586.2348175303109 24.40999984741211 39.530364990234375" preserveAspectRatio="none">\
              	  <g>\
              	    <defs>\
              	      <path id="s-Path_4-76775" d="M330.2348175303099 586.2348175303109 L325.59000015258744 590.8796349080334 L340.6774225197899 606.0000000000003 L325.59000015258744 621.1203650919673 L330.2348175303099 625.7651824696898 L349.99999999999955 606.0000000000003 L330.2348175303099 586.2348175303109 Z "></path>\
              	    </defs>\
              	    <g style="mix-blend-mode:normal">\
              	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_4-76775" fill="#3F51B5" fill-opacity="1.0"></use>\
              	    </g>\
              	  </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_5" class="richtext manualfit firer ie-background commentable non-processed" customid="Siguiente"   datasizewidth="170.9px" datasizeheight="68.0px" dataX="189.1" dataY="572.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_5_0">Siguiente &nbsp; &nbsp;</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Hotspot_2" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 2"   datasizewidth="180.0px" datasizeheight="68.0px" dataX="180.0" dataY="572.0"  >\
            <div class="clickableSpot"></div>\
          </div>\
        </div>\
\
      </div>\
\
\
      <div id="s-Group_3" class="group firer ie-background commentable non-processed" customid="area" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Group_7" class="group firer ie-background commentable non-processed" customid="radio buttons" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Input_1" class="inputAndroid radiobutton firer commentable non-processed checked" customid="Radio button 1"  datasizewidth="30.0px" datasizeheight="30.0px" dataX="269.0" dataY="214.0"  name="s-Group_3" value="true"  checked="checked" tabindex="-1" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
          </div>\
          <div id="s-Input_2" class="inputAndroid radiobutton firer commentable non-processed unchecked" customid="Radio button 1"  datasizewidth="30.0px" datasizeheight="30.0px" dataX="269.0" dataY="274.0"  name="s-Group_3"    tabindex="-1" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
          </div>\
          <div id="s-Input_3" class="inputAndroid radiobutton firer commentable non-processed unchecked" customid="Radio button 1"  datasizewidth="30.0px" datasizeheight="30.0px" dataX="269.0" dataY="334.0"  name="s-Group_3"    tabindex="-1" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
          </div>\
          <div id="s-Input_4" class="inputAndroid radiobutton firer commentable non-processed unchecked" customid="Radio button 1"  datasizewidth="30.0px" datasizeheight="30.0px" dataX="269.0" dataY="394.0"  name="s-Group_3"    tabindex="-1" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Paragraph_6" class="richtext autofit firer ie-background commentable non-processed" customid="Ruta creada 4"   datasizewidth="188.5px" datasizeheight="34.0px" dataX="52.4" dataY="392.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_6_0">Ruta creada</span><span id="rtr-s-Paragraph_6_1"> 4</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_8" class="richtext autofit firer ie-background commentable non-processed" customid="Ruta creada 3"   datasizewidth="188.5px" datasizeheight="34.0px" dataX="52.4" dataY="332.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_8_0">Ruta creada</span><span id="rtr-s-Paragraph_8_1"> 3</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_9" class="richtext autofit firer ie-background commentable non-processed" customid="Ruta creada 2"   datasizewidth="188.5px" datasizeheight="34.0px" dataX="52.4" dataY="272.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_9_0">Ruta creada 2</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_10" class="richtext autofit firer ie-background commentable non-processed" customid="Ruta creada 1"   datasizewidth="188.5px" datasizeheight="34.0px" dataX="52.4" dataY="212.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_10_0">Ruta creada 1</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_3" class="path firer ie-background commentable non-processed" customid="Line 1"   datasizewidth="311.4px" datasizeheight="3.0px" dataX="24.9" dataY="160.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="310.3797302246094" height="2.7036314010620117" viewBox="24.888999938966073 160.00000131130267 310.3797302246094 2.7036314010620117" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_3-76775" d="M25.390136718751137 161.00000000000034 L334.76757812500125 161.70363389121738 "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_3-76775" fill="none" stroke-width="1.0" stroke="#434343" stroke-linecap="butt"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_11" class="richtext autofit firer ie-background commentable non-processed" customid="Seleccione una ruta"   datasizewidth="309.4px" datasizeheight="40.0px" dataX="25.4" dataY="121.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_11_0">Seleccione una ruta</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_1" class="group firer ie-background commentable hidden non-processed" customid="popup eliminar" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 5"   datasizewidth="275.0px" datasizeheight="246.0px" datasizewidthpx="275.00000000000006" datasizeheightpx="245.99999999999994" dataX="42.5" dataY="177.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_1_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_1" class="richtext manualfit firer click commentable non-processed" customid="No"   datasizewidth="139.8px" datasizeheight="63.8px" dataX="177.7" dataY="359.2" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_1_0">No</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_2" class="richtext manualfit firer ie-background commentable non-processed" customid="&iquest;Desea eliminar la ruta?"   datasizewidth="275.0px" datasizeheight="185.5px" dataX="42.5" dataY="177.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_2_0">&iquest;Desea eliminar la ruta?</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_3" class="richtext manualfit firer click commentable non-processed" customid="Si"   datasizewidth="139.5px" datasizeheight="63.5px" dataX="42.5" dataY="359.2" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_3_0">Si</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="top" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="BG - optional"   datasizewidth="360.0px" datasizeheight="69.0px" datasizewidthpx="360.00000000000045" datasizeheightpx="68.99999999999997" dataX="-0.0" dataY="-0.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_2_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_1" class="path firer commentable non-processed" customid="Account_circle"   datasizewidth="50.0px" datasizeheight="50.0px" dataX="300.0" dataY="10.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="50.0" height="50.0" viewBox="300.0000000000002 9.999999999999572 50.0 50.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_1-76775" d="M325.0000000000002 9.999999999999572 C311.20000004768394 9.999999999999572 300.0000000000002 21.200000047683286 300.0000000000002 34.99999999999957 C300.0000000000002 48.79999995231585 311.20000004768394 59.99999999999957 325.0000000000002 59.99999999999957 C338.7999999523165 59.99999999999957 350.0000000000002 48.79999995231585 350.0000000000002 34.99999999999957 C350.0000000000002 21.200000047683286 338.8000011444094 9.999999999999572 325.0000000000002 9.999999999999572 Z M325.0000000000002 17.49999999999957 C329.1499999165537 17.49999999999957 332.5000000000002 20.850000083446073 332.5000000000002 24.999999999999567 C332.5000000000002 29.149999916553064 329.1499999165537 32.49999999999957 325.0000000000002 32.49999999999957 C320.85000008344673 32.49999999999957 317.5000000000002 29.149999916553064 317.5000000000002 24.999999999999567 C317.5000000000002 20.850000083446073 320.85000008344673 17.49999999999957 325.0000000000002 17.49999999999957 Z M325.0000000000002 52.99999952316241 C318.7500000000002 52.99999952316241 313.2249999046328 49.79999959468798 310.0000000000002 44.949999451636835 C310.07499999832385 39.97499942779498 320.0000000000002 37.24999964237169 325.0000000000002 37.24999964237169 C329.9750000238421 37.24999964237169 339.92499947547935 39.9749997258182 340.0000000000002 44.949999451636835 C336.77500009536766 49.79999959468798 331.2500000000002 52.99999952316241 325.0000000000002 52.99999952316241 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-76775" fill="#EFEFEF" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_4" class="richtext manualfit firer ie-background commentable non-processed" customid="Crear ruta"   datasizewidth="240.0px" datasizeheight="69.0px" dataX="60.0" dataY="-0.5" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_4_0">Crear ruta</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_2" class="path firer commentable non-processed" customid="Home"   datasizewidth="50.0px" datasizeheight="48.0px" dataX="10.0" dataY="10.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="50.0" height="48.0" viewBox="10.0 10.00000000000017 50.0 48.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_2-76775" d="M30.0 58.00000000000017 L30.0 41.05882352941194 L40.0 41.05882352941194 L40.0 58.00000000000017 L52.5 58.00000000000017 L52.5 35.41176470588253 L60.0 35.41176470588253 L35.0 10.00000000000017 L10.0 35.41176470588253 L17.5 35.41176470588253 L17.5 58.00000000000017 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-76775" fill="#EFEFEF" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Hotspot_1" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 2"   datasizewidth="71.0px" datasizeheight="69.0px" dataX="-0.0" dataY="0.0"  >\
          <div class="clickableSpot"></div>\
        </div>\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;