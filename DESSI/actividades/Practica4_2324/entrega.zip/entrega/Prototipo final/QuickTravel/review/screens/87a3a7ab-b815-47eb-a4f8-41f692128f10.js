var content='<div class="ui-page " deviceName="androidphone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1707248953625.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-87a3a7ab-b815-47eb-a4f8-41f692128f10" class="screen growth-vertical devMobile devAndroid android-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="crear ruta 4"width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/87a3a7ab-b815-47eb-a4f8-41f692128f10-1707248953625.css" />\
      <div class="freeLayout">\
      <div id="s-Group_9" class="group firer ie-background commentable non-processed" customid="bottom bar" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_9" class="rectangle manualfit firer commentable non-processed" customid="BG - optional"   datasizewidth="360.0px" datasizeheight="68.0px" datasizewidthpx="360.00000000000017" datasizeheightpx="68.0" dataX="-0.0" dataY="572.5" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_9_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_15" class="path firer ie-background commentable non-processed" customid="Line 1"   datasizewidth="362.0px" datasizeheight="3.0px" dataX="-0.5" dataY="571.5"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="361.0005798339844" height="2.2036337852478027" viewBox="-0.5002822875974289 571.5000001192096 361.0005798339844 2.2036337852478027" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_15-87a3a" d="M-2.8421709430404007E-14 572.5 L360.0000000000003 572.7036338912172 "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_15-87a3a" fill="none" stroke-width="1.0" stroke="#3F51B5" stroke-linecap="butt"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Group_10" class="group firer ie-background commentable non-processed" customid="guardar" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Path_16" class="path firer commentable non-processed" customid="Save"   datasizewidth="38.0px" datasizeheight="38.0px" dataX="312.0" dataY="586.5"  >\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg xmlns="http://www.w3.org/2000/svg" width="38.0" height="38.0" viewBox="312.0 586.5000000000001 38.0 38.0" preserveAspectRatio="none">\
              	  <g>\
              	    <defs>\
              	      <path id="s-Path_16-87a3a" d="M341.5555555555559 586.5000000000001 L316.2222222222223 586.5000000000001 C313.8788888586892 586.5000000000001 312.0 588.3999999496673 312.0 590.7222222222224 L312.0 620.277777777778 C312.0 622.6000000503332 313.8788888586892 624.5000000000003 316.2222222222223 624.5000000000003 L345.77777777777817 624.5000000000003 C348.1000000503333 624.5000000000003 350.00000000000045 622.6000000503332 350.00000000000045 620.277777777778 L350.00000000000045 594.9444444444446 L341.5555555555559 586.5000000000001 Z M331.0000000000002 620.277777777778 C327.49555562602166 620.277777777778 324.6666666666668 617.4488888184233 324.6666666666668 613.9444444444447 C324.6666666666668 610.4400000704662 327.49555562602166 607.6111111111113 331.0000000000002 607.6111111111113 C334.5044443739788 607.6111111111113 337.33333333333366 610.4400000704662 337.33333333333366 613.9444444444447 C337.33333333333366 617.4488888184233 334.5044443739788 620.277777777778 331.0000000000002 620.277777777778 Z M337.33333333333366 599.1666666666669 L316.2222222222223 599.1666666666669 L316.2222222222223 590.7222222222224 L337.33333333333366 590.7222222222224 L337.33333333333366 599.1666666666669 Z "></path>\
              	    </defs>\
              	    <g style="mix-blend-mode:normal">\
              	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_16-87a3a" fill="#3F51B5" fill-opacity="1.0"></use>\
              	    </g>\
              	  </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_10" class="richtext manualfit firer ie-background commentable non-processed" customid="Guardar"   datasizewidth="170.9px" datasizeheight="68.0px" dataX="184.1" dataY="572.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_10_0">Guardar &nbsp; &nbsp; &nbsp;</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Hotspot_6" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 2"   datasizewidth="180.0px" datasizeheight="68.0px" dataX="180.0" dataY="572.5"  >\
            <div class="clickableSpot"></div>\
          </div>\
        </div>\
\
\
        <div id="s-Group_11" class="group firer ie-background commentable non-processed" customid="Anterior" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Paragraph_11" class="richtext manualfit firer ie-background commentable non-processed" customid="Anterior"   datasizewidth="170.9px" datasizeheight="68.0px" dataX="9.1" dataY="572.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_11_0"> &nbsp; Anterior</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Path_17" class="path firer commentable non-processed" customid="Chevron Left"   datasizewidth="24.4px" datasizeheight="39.5px" dataX="9.5" dataY="585.2"  >\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg xmlns="http://www.w3.org/2000/svg" width="25.40999984741211" height="40.530364990234375" viewBox="9.49999999999983 585.234817724732 25.40999984741211 40.530364990234375" preserveAspectRatio="none">\
              	  <g>\
              	    <defs>\
              	      <path id="s-Path_17-87a3a" d="M34.40999960730093 590.3796350567654 L29.76518227526759 585.734817724732 L9.99999999999983 605.5 L29.76518227526759 625.265182275268 L34.409999999999826 620.6203645505357 L19.322577388507167 605.5 L34.40999960730093 590.3796350567654 Z "></path>\
              	    </defs>\
              	    <g style="mix-blend-mode:normal">\
              	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_17-87a3a" fill="#3F51B5" fill-opacity="1.0"></use>\
              	    </g>\
              	  </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
          <div id="s-Hotspot_7" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 2"   datasizewidth="180.0px" datasizeheight="69.0px" dataX="0.0" dataY="572.0"  >\
            <div class="clickableSpot"></div>\
          </div>\
        </div>\
\
      </div>\
\
      <div id="s-Dynamic_Panel_1" class="dynamicpanel firer ie-background commentable non-processed" customid="lista edirar" datasizewidth="361.0px" datasizeheight="290.0px" dataX="-0.5" dataY="238.0" >\
        <div id="s-Panel_1" class="panel default firer ie-background commentable non-processed" customid="Panel"  datasizewidth="361.0px" datasizeheight="290.0px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <table class="layout" summary="">\
                  <tr>\
                    <td class="layout vertical insertionpoint verticalalign Panel_1 Dynamic_Panel_1" valign="top" align="left" hSpacing="0" vSpacing="0"><div class="relativeLayoutWrapper s-Group_4 "><div class="relativeLayoutWrapperResponsive">\
                <div id="s-Group_4" class="group firer ie-background commentable non-processed" customid="Two lines item list 6" datasizewidth="0.0px" datasizeheight="0.0px" >\
                  <div id="s-Rectangle_4" class="rectangle manualfit firer commentable non-processed" customid="BG"   datasizewidth="360.0px" datasizeheight="72.0px" datasizewidthpx="360.0" datasizeheightpx="72.0" dataX="0.0" dataY="0.2" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Rectangle_4_0"></span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Path_7" class="path firer commentable non-processed" customid="Drag handle icon"   datasizewidth="25.0px" datasizeheight="10.4px" dataX="283.6" dataY="34.4"  >\
                    <div class="borderLayer">\
                    	<div class="imageViewport">\
                      	<?xml version="1.0" encoding="UTF-8"?>\
                      	<svg xmlns="http://www.w3.org/2000/svg" width="25.0" height="10.3515625" viewBox="283.64106142634455 34.445792923539784 25.0 10.3515625" preserveAspectRatio="none">\
                      	  <g>\
                      	    <defs>\
                      	      <path id="s-Path_7-87a3a" d="M283.6410614263446 43.234855423539784 L283.6410614263446 41.867667923539784 L308.6410614263446 41.867667923539784 L308.6410614263446 44.797355423539784 L283.6410614263446 44.797355423539784 Z M283.6410614263446 37.375480423539784 L283.6410614263446 34.445792923539784 L308.6410614263446 34.445792923539784 L308.6410614263446 37.375480423539784 L283.6410614263446 37.375480423539784 Z "></path>\
                      	    </defs>\
                      	    <g style="mix-blend-mode:normal">\
                      	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_7-87a3a" fill="#434343" fill-opacity="1.0"></use>\
                      	    </g>\
                      	  </g>\
                      	</svg>\
\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Paragraph_3" class="richtext manualfit firer ie-background commentable non-processed" customid="Localizaci&oacute;n 1"   datasizewidth="173.1px" datasizeheight="42.0px" dataX="87.6" dataY="17.4" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Paragraph_3_0">Localizaci&oacute;n 1</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Path_8" class="path firer commentable non-processed" customid="Location On"   datasizewidth="25.0px" datasizeheight="35.7px" dataX="39.6" dataY="19.2"  >\
                    <div class="borderLayer">\
                    	<div class="imageViewport">\
                      	<?xml version="1.0" encoding="UTF-8"?>\
                      	<svg xmlns="http://www.w3.org/2000/svg" width="25.0" height="35.71428680419922" viewBox="39.64106142634381 19.195792923539216 25.0 35.71428680419922" preserveAspectRatio="none">\
                      	  <g>\
                      	    <defs>\
                      	      <path id="s-Path_8-87a3a" d="M52.14106142634381 19.195792923539216 C45.23034734498831 19.195792923539216 39.64106142634381 24.785078842183715 39.64106142634381 31.695792923539216 C39.64106142634381 41.070792923539216 52.14106142634381 54.91007863782493 52.14106142634381 54.91007863782493 C52.14106142634381 54.91007863782493 64.64106142634381 41.070792923539216 64.64106142634381 31.695792923539216 C64.64106142634381 24.785078842183715 59.05177550769932 19.195792923539216 52.14106142634381 19.195792923539216 Z M52.14106142634381 36.16007863782493 C49.67677572057305 36.16007863782493 47.676775712058095 34.16007862930998 47.676775712058095 31.695792923539216 C47.676775712058095 29.231507217768453 49.67677572057305 27.2315072092535 52.14106142634381 27.2315072092535 C54.605347132114574 27.2315072092535 56.605347140629526 29.231507217768453 56.605347140629526 31.695792923539216 C56.605347140629526 34.16007862930998 54.605347132114574 36.16007863782493 52.14106142634381 36.16007863782493 Z "></path>\
                      	    </defs>\
                      	    <g style="mix-blend-mode:normal">\
                      	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_8-87a3a" fill="#434343" fill-opacity="1.0"></use>\
                      	    </g>\
                      	  </g>\
                      	</svg>\
\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Hotspot_2" class="imagemap firer dragstart drag dragend ie-background commentable non-processed" customid="Hotspot"   datasizewidth="360.0px" datasizeheight="72.0px" dataX="0.0" dataY="0.0"  >\
                    <div class="clickableSpot"></div>\
                  </div>\
                </div>\
                </div></div><div class="relativeLayoutWrapper s-Group_5 "><div class="relativeLayoutWrapperResponsive">\
                <div id="s-Group_5" class="group firer ie-background commentable non-processed" customid="Two lines item list 7" datasizewidth="0.0px" datasizeheight="0.0px" >\
                  <div id="s-Rectangle_5" class="rectangle manualfit firer commentable non-processed" customid="BG"   datasizewidth="360.0px" datasizeheight="72.0px" datasizewidthpx="360.0" datasizeheightpx="72.0" dataX="0.0" dataY="73.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Rectangle_5_0"></span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Path_9" class="path firer commentable non-processed" customid="Drag handle icon"   datasizewidth="25.0px" datasizeheight="10.4px" dataX="283.1" dataY="104.7"  >\
                    <div class="borderLayer">\
                    	<div class="imageViewport">\
                      	<?xml version="1.0" encoding="UTF-8"?>\
                      	<svg xmlns="http://www.w3.org/2000/svg" width="25.0" height="10.3515625" viewBox="283.1410614263451 104.69579292353978 25.0 10.3515625" preserveAspectRatio="none">\
                      	  <g>\
                      	    <defs>\
                      	      <path id="s-Path_9-87a3a" d="M283.1410614263452 113.48485542353978 L283.1410614263452 112.11766792353978 L308.1410614263452 112.11766792353978 L308.1410614263452 115.04735542353978 L283.1410614263452 115.04735542353978 Z M283.1410614263452 107.62548042353978 L283.1410614263452 104.69579292353978 L308.1410614263452 104.69579292353978 L308.1410614263452 107.62548042353978 L283.1410614263452 107.62548042353978 Z "></path>\
                      	    </defs>\
                      	    <g style="mix-blend-mode:normal">\
                      	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_9-87a3a" fill="#434343" fill-opacity="1.0"></use>\
                      	    </g>\
                      	  </g>\
                      	</svg>\
\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Paragraph_4" class="richtext manualfit firer ie-background commentable non-processed" customid="Localizaci&oacute;n 2"   datasizewidth="173.1px" datasizeheight="42.0px" dataX="87.1" dataY="87.7" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Paragraph_4_0">Localizaci&oacute;n 2</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Path_10" class="path firer commentable non-processed" customid="Location On"   datasizewidth="25.0px" datasizeheight="35.7px" dataX="39.1" dataY="89.4"  >\
                    <div class="borderLayer">\
                    	<div class="imageViewport">\
                      	<?xml version="1.0" encoding="UTF-8"?>\
                      	<svg xmlns="http://www.w3.org/2000/svg" width="25.0" height="35.71428680419922" viewBox="39.14106142634438 89.4457929235391 25.0 35.71428680419922" preserveAspectRatio="none">\
                      	  <g>\
                      	    <defs>\
                      	      <path id="s-Path_10-87a3a" d="M51.64106142634438 89.4457929235391 C44.73034734498888 89.4457929235391 39.14106142634438 95.0350788421836 39.14106142634438 101.9457929235391 C39.14106142634438 111.3207929235391 51.64106142634438 125.16007863782482 51.64106142634438 125.16007863782482 C51.64106142634438 125.16007863782482 64.14106142634438 111.3207929235391 64.14106142634438 101.9457929235391 C64.14106142634438 95.0350788421836 58.55177550769989 89.4457929235391 51.64106142634438 89.4457929235391 Z M51.64106142634438 106.41007863782482 C49.176775720573616 106.41007863782482 47.176775712058664 104.41007862930987 47.176775712058664 101.9457929235391 C47.176775712058664 99.48150721776834 49.176775720573616 97.4815072092534 51.64106142634438 97.4815072092534 C54.10534713211514 97.4815072092534 56.105347140630094 99.48150721776834 56.105347140630094 101.9457929235391 C56.105347140630094 104.41007862930987 54.10534713211514 106.41007863782482 51.64106142634438 106.41007863782482 Z "></path>\
                      	    </defs>\
                      	    <g style="mix-blend-mode:normal">\
                      	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_10-87a3a" fill="#434343" fill-opacity="1.0"></use>\
                      	    </g>\
                      	  </g>\
                      	</svg>\
\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Hotspot_3" class="imagemap firer dragstart drag dragend ie-background commentable non-processed" customid="Hotspot"   datasizewidth="360.0px" datasizeheight="72.0px" dataX="0.0" dataY="72.2"  >\
                    <div class="clickableSpot"></div>\
                  </div>\
                </div>\
                </div></div><div class="relativeLayoutWrapper s-Group_6 "><div class="relativeLayoutWrapperResponsive">\
                <div id="s-Group_6" class="group firer ie-background commentable non-processed" customid="Two lines item list 8" datasizewidth="0.0px" datasizeheight="0.0px" >\
                  <div id="s-Rectangle_6" class="rectangle manualfit firer commentable non-processed" customid="BG"   datasizewidth="360.0px" datasizeheight="72.0px" datasizewidthpx="360.0" datasizeheightpx="72.0" dataX="0.0" dataY="145.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Rectangle_6_0"></span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Path_11" class="path firer commentable non-processed" customid="Drag handle icon"   datasizewidth="25.0px" datasizeheight="10.4px" dataX="283.6" dataY="179.4"  >\
                    <div class="borderLayer">\
                    	<div class="imageViewport">\
                      	<?xml version="1.0" encoding="UTF-8"?>\
                      	<svg xmlns="http://www.w3.org/2000/svg" width="25.0" height="10.3515625" viewBox="283.64106142634455 179.44579292354024 25.0 10.3515625" preserveAspectRatio="none">\
                      	  <g>\
                      	    <defs>\
                      	      <path id="s-Path_11-87a3a" d="M283.6410614263446 188.23485542354024 L283.6410614263446 186.86766792354024 L308.6410614263446 186.86766792354024 L308.6410614263446 189.79735542354024 L283.6410614263446 189.79735542354024 Z M283.6410614263446 182.37548042354024 L283.6410614263446 179.44579292354024 L308.6410614263446 179.44579292354024 L308.6410614263446 182.37548042354024 L283.6410614263446 182.37548042354024 Z "></path>\
                      	    </defs>\
                      	    <g style="mix-blend-mode:normal">\
                      	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_11-87a3a" fill="#434343" fill-opacity="1.0"></use>\
                      	    </g>\
                      	  </g>\
                      	</svg>\
\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Paragraph_5" class="richtext manualfit firer ie-background commentable non-processed" customid="Localizaci&oacute;n 3"   datasizewidth="173.1px" datasizeheight="42.0px" dataX="87.6" dataY="162.4" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Paragraph_5_0">Localizaci&oacute;n 3</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Path_12" class="path firer commentable non-processed" customid="Location On"   datasizewidth="25.0px" datasizeheight="35.7px" dataX="39.6" dataY="164.2"  >\
                    <div class="borderLayer">\
                    	<div class="imageViewport">\
                      	<?xml version="1.0" encoding="UTF-8"?>\
                      	<svg xmlns="http://www.w3.org/2000/svg" width="25.0" height="35.71428680419922" viewBox="39.64106142634381 164.19579292353984 25.0 35.71428680419922" preserveAspectRatio="none">\
                      	  <g>\
                      	    <defs>\
                      	      <path id="s-Path_12-87a3a" d="M52.14106142634381 164.19579292353984 C45.23034734498831 164.19579292353984 39.64106142634381 169.78507884218433 39.64106142634381 176.69579292353984 C39.64106142634381 186.07079292353984 52.14106142634381 199.91007863782556 52.14106142634381 199.91007863782556 C52.14106142634381 199.91007863782556 64.64106142634381 186.07079292353984 64.64106142634381 176.69579292353984 C64.64106142634381 169.78507884218433 59.05177550769932 164.19579292353984 52.14106142634381 164.19579292353984 Z M52.14106142634381 181.16007863782556 C49.67677572057305 181.16007863782556 47.676775712058095 179.1600786293106 47.676775712058095 176.69579292353984 C47.676775712058095 174.23150721776906 49.67677572057305 172.23150720925412 52.14106142634381 172.23150720925412 C54.605347132114574 172.23150720925412 56.605347140629526 174.23150721776906 56.605347140629526 176.69579292353984 C56.605347140629526 179.1600786293106 54.605347132114574 181.16007863782556 52.14106142634381 181.16007863782556 Z "></path>\
                      	    </defs>\
                      	    <g style="mix-blend-mode:normal">\
                      	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_12-87a3a" fill="#434343" fill-opacity="1.0"></use>\
                      	    </g>\
                      	  </g>\
                      	</svg>\
\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Hotspot_4" class="imagemap firer dragstart drag dragend ie-background commentable non-processed" customid="Hotspot"   datasizewidth="360.0px" datasizeheight="72.0px" dataX="0.0" dataY="145.2"  >\
                    <div class="clickableSpot"></div>\
                  </div>\
                </div>\
                </div></div><div class="relativeLayoutWrapper s-Group_7 "><div class="relativeLayoutWrapperResponsive">\
                <div id="s-Group_7" class="group firer ie-background commentable non-processed" customid="Two lines item list 9" datasizewidth="0.0px" datasizeheight="0.0px" >\
                  <div id="s-Rectangle_7" class="rectangle manualfit firer commentable non-processed" customid="BG"   datasizewidth="360.0px" datasizeheight="72.0px" datasizewidthpx="360.0" datasizeheightpx="72.0" dataX="0.0" dataY="217.5" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Rectangle_7_0"></span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Path_13" class="path firer commentable non-processed" customid="Drag handle icon"   datasizewidth="25.0px" datasizeheight="10.4px" dataX="284.0" dataY="249.0"  >\
                    <div class="borderLayer">\
                    	<div class="imageViewport">\
                      	<?xml version="1.0" encoding="UTF-8"?>\
                      	<svg xmlns="http://www.w3.org/2000/svg" width="25.0" height="10.3515625" viewBox="283.99999999999994 249.0 25.0 10.3515625" preserveAspectRatio="none">\
                      	  <g>\
                      	    <defs>\
                      	      <path id="s-Path_13-87a3a" d="M284.0 257.7890625 L284.0 256.421875 L309.0 256.421875 L309.0 259.3515625 L284.0 259.3515625 Z M284.0 251.9296875 L284.0 249.0 L309.0 249.0 L309.0 251.9296875 L284.0 251.9296875 Z "></path>\
                      	    </defs>\
                      	    <g style="mix-blend-mode:normal">\
                      	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_13-87a3a" fill="#434343" fill-opacity="1.0"></use>\
                      	    </g>\
                      	  </g>\
                      	</svg>\
\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Paragraph_6" class="richtext manualfit firer ie-background commentable non-processed" customid="Localizaci&oacute;n 4"   datasizewidth="173.1px" datasizeheight="42.0px" dataX="88.0" dataY="232.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Paragraph_6_0">Localizaci&oacute;n 4</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Path_14" class="path firer commentable non-processed" customid="Location On"   datasizewidth="25.0px" datasizeheight="35.7px" dataX="40.0" dataY="233.7"  >\
                    <div class="borderLayer">\
                    	<div class="imageViewport">\
                      	<?xml version="1.0" encoding="UTF-8"?>\
                      	<svg xmlns="http://www.w3.org/2000/svg" width="25.0" height="35.71428680419922" viewBox="40.0 233.74999999999983 25.0 35.71428680419922" preserveAspectRatio="none">\
                      	  <g>\
                      	    <defs>\
                      	      <path id="s-Path_14-87a3a" d="M52.5 233.74999999999983 C45.5892859186445 233.74999999999983 40.0 239.33928591864432 40.0 246.24999999999983 C40.0 255.62499999999983 52.5 269.46428571428555 52.5 269.46428571428555 C52.5 269.46428571428555 65.0 255.62499999999983 65.0 246.24999999999983 C65.0 239.33928591864432 59.41071408135551 233.74999999999983 52.5 233.74999999999983 Z M52.5 250.71428571428555 C50.03571429422924 250.71428571428555 48.035714285714285 248.71428570577058 48.035714285714285 246.24999999999983 C48.035714285714285 243.78571429422905 50.03571429422924 241.7857142857141 52.5 241.7857142857141 C54.96428570577076 241.7857142857141 56.964285714285715 243.78571429422905 56.964285714285715 246.24999999999983 C56.964285714285715 248.71428570577058 54.96428570577076 250.71428571428555 52.5 250.71428571428555 Z "></path>\
                      	    </defs>\
                      	    <g style="mix-blend-mode:normal">\
                      	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_14-87a3a" fill="#434343" fill-opacity="1.0"></use>\
                      	    </g>\
                      	  </g>\
                      	</svg>\
\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Hotspot_5" class="imagemap firer dragstart drag dragend ie-background commentable non-processed" customid="Hotspot"   datasizewidth="360.0px" datasizeheight="72.0px" dataX="0.0" dataY="217.2"  >\
                    <div class="clickableSpot"></div>\
                  </div>\
                </div>\
                </div></div></td> \
                  </tr>\
                </table>\
\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_3" class="group firer ie-background commentable non-processed" customid="vehicles" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_3" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 3"   datasizewidth="360.0px" datasizeheight="90.9px" datasizewidthpx="359.99999999999835" datasizeheightpx="90.94921875" dataX="0.0" dataY="69.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_3_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_3" class="path firer commentable non-processed" customid="Bike"   datasizewidth="50.0px" datasizeheight="42.7px" dataX="35.0" dataY="100.6"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="50.0" height="42.70833206176758" viewBox="35.00000000000081 100.62044270833339 50.0 42.70833206176758" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_3-87a3a" d="M67.29166666666748 108.95377604166671 C69.58333338300469 108.95377604166671 71.45833333333414 107.07877609133726 71.45833333333414 104.78710937500006 C71.45833333333414 102.49544265866285 69.58333338300469 100.62044270833339 67.29166666666748 100.62044270833339 C64.99999995033028 100.62044270833339 63.12500000000081 102.49544265866285 63.12500000000081 104.78710937500006 C63.12500000000081 107.07877609133726 64.99999995033028 108.95377604166671 67.29166666666748 108.95377604166671 Z M45.41666666666748 122.49544270833339 C39.58333343267522 122.49544270833339 35.00000000000081 127.0787761410078 35.00000000000081 132.91210937500006 C35.00000000000081 138.7454426089923 39.58333343267522 143.3287760416667 45.41666666666748 143.3287760416667 C51.24999990065974 143.3287760416667 55.833333333334146 138.7454426089923 55.833333333334146 132.91210937500006 C55.833333333334146 127.0787761410078 51.24999990065974 122.49544270833339 45.41666666666748 122.49544270833339 Z M45.41666666666748 140.2037760416667 C41.45833338300468 140.2037760416667 38.12500000000081 136.87044265866285 38.12500000000081 132.91210937500006 C38.12500000000081 128.95377609133726 41.45833338300468 125.62044270833339 45.41666666666748 125.62044270833339 C49.37499995033028 125.62044270833339 52.708333333334146 128.95377609133726 52.708333333334146 132.91210937500006 C52.708333333334146 136.87044265866285 49.37499995033028 140.2037760416667 45.41666666666748 140.2037760416667 Z M57.50000039736511 119.37044270833339 L62.50000059604726 114.37044250965124 L64.16666728754919 116.03710920115317 C66.87500052154145 118.74544243514543 70.41666728754919 120.41210900247103 74.79166708886704 120.41210900247103 L74.79166708886704 116.24544270833339 C71.66666708886704 116.24544270833339 69.16666698952596 114.99544265866285 67.29166728754919 113.12044270833339 L63.3333340038864 109.16210942467059 C62.291667337219735 108.32877607891962 61.250000670553064 107.91210937500006 60.00000062088253 107.91210937500006 C58.75000057121199 107.91210937500006 57.70833390454533 108.32877604787554 57.0833340038864 109.16210942467059 L51.25000039736511 114.9954419136048 C50.41666705161414 115.82877525935575 50.000000347694574 116.87044186393425 50.000000347694574 117.91210853060092 C50.000000347694574 119.16210858027145 50.41666702057006 120.20377524693812 51.25000039736511 120.82877514759704 L57.91666666666748 126.66210937500006 L57.91666666666748 137.0787760416667 L62.083333333334146 137.0787760416667 L62.083333333334146 124.16210977236435 L57.49999990065974 119.37044320503875 Z M74.58333333333414 122.49544270833339 C68.75000009934189 122.49544270833339 64.16666666666748 127.0787761410078 64.16666666666748 132.91210937500006 C64.16666666666748 138.7454426089923 68.75000009934189 143.3287760416667 74.58333333333414 143.3287760416667 C80.4166665673264 143.3287760416667 85.00000000000081 138.7454426089923 85.00000000000081 132.91210937500006 C85.00000000000081 127.0787761410078 80.4166665673264 122.49544270833339 74.58333333333414 122.49544270833339 Z M74.58333333333414 140.2037760416667 C70.62500004967134 140.2037760416667 67.29166666666748 136.87044265866285 67.29166666666748 132.91210937500006 C67.29166666666748 128.95377609133726 70.62500004967134 125.62044270833339 74.58333333333414 125.62044270833339 C78.54166661699693 125.62044270833339 81.87500000000081 128.95377609133726 81.87500000000081 132.91210937500006 C81.87500000000081 136.87044265866285 78.54166661699693 140.2037760416667 74.58333333333414 140.2037760416667 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_3-87a3a" fill="#434343" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_4" class="path firer commentable non-processed" customid="Car"   datasizewidth="50.0px" datasizeheight="44.4px" dataX="115.0" dataY="99.8"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="50.0" height="44.44444274902344" viewBox="115.00000000000058 99.75238715277776 50.0 44.44444274902344" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_4-87a3a" d="M159.22222243415044 102.5579433441162 C158.66666475931862 100.91905403137206 157.11111068725646 99.75238715277776 155.27777777777837 99.75238715277776 L124.72222222222281 99.75238715277776 C122.88888881603935 99.75238715277776 121.36111100514788 100.91905378301936 120.77777789698766 102.55794268184236 L115.00000000000058 119.19683159722226 L115.00000000000058 141.41905381944454 C115.00000000000058 142.94683163033602 116.24999996688689 144.19683159722234 117.77777777777837 144.19683159722234 L120.55555555555614 144.19683159722234 C122.0833333664476 144.19683159722234 123.33333333333391 142.94683163033602 123.33333333333391 141.41905381944454 L123.33333333333391 138.64127604166674 L156.66666666666725 138.64127604166674 L156.66666666666725 141.41905381944454 C156.66666666666725 142.94683163033602 157.91666663355358 144.19683159722234 159.44444444444503 144.19683159722234 L162.22222222222283 144.19683159722234 C163.75000003311428 144.19683159722234 165.00000000000057 142.94683163033602 165.00000000000057 141.41905381944454 L165.00000000000057 119.19683159722226 L159.22222243415044 102.5579433441162 Z M124.72222222222281 130.3079427083334 C122.41666671302642 130.3079427083334 120.55555555555614 128.44683155086312 120.55555555555614 126.14127604166671 C120.55555555555614 123.83572053247032 122.41666687859488 121.97460937500004 124.72222222222281 121.97460937500004 C127.02777756585074 121.97460937500004 128.88888888888948 123.83572053247032 128.88888888888948 126.14127604166671 C128.88888888888948 128.44683155086312 127.02777756585074 130.3079427083334 124.72222222222281 130.3079427083334 Z M155.27777777777837 130.3079427083334 C152.972222268582 130.3079427083334 151.1111111111117 128.44683155086312 151.1111111111117 126.14127604166671 C151.1111111111117 123.83572053247032 152.972222268582 121.97460937500004 155.27777777777837 121.97460937500004 C157.58333328697475 121.97460937500004 159.44444444444503 123.83572053247032 159.44444444444503 126.14127604166671 C159.44444444444503 128.44683155086312 157.58333328697475 130.3079427083334 155.27777777777837 130.3079427083334 Z M120.55555555555614 116.41905381944447 L124.72222222222281 103.91905381944443 L155.27777777777837 103.91905381944443 L159.44444444444503 116.41905381944447 L120.55555555555614 116.41905381944447 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_4-87a3a" fill="#434343" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_5" class="path firer commentable non-processed" customid="Bus"   datasizewidth="50.0px" datasizeheight="59.4px" dataX="195.0" dataY="84.8"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="50.0" height="59.375" viewBox="195.0 84.75238715277777 50.0 59.375" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_5-87a3a" d="M195.0 128.50238715277777 C195.0 131.2523871378766 196.21874995529652 133.72113701866732 198.125 135.43988724218474 L198.125 141.00238715277777 C198.125 142.72113719003067 199.5312499627471 144.12738715277777 201.25 144.12738715277777 L204.375 144.12738715277777 C206.0937500372529 144.12738715277777 207.5 142.72113719003067 207.5 141.00238715277777 L207.5 137.87738715277777 L232.5 137.87738715277777 L232.5 141.00238715277777 C232.5 142.72113719003067 233.9062499627471 144.12738715277777 235.625 144.12738715277777 L238.75 144.12738715277777 C240.4687500372529 144.12738715277777 241.875 142.72113719003067 241.875 141.00238715277777 L241.875 135.43988724218474 C243.78125004470348 133.72113720493184 245.0 131.2523871378766 245.0 128.50238715277777 L245.0 97.25238715277777 C245.0 86.31488715277777 233.81250023841858 84.75238715277777 220.0 84.75238715277777 C206.18749976158142 84.75238715277777 195.0 86.31488715277777 195.0 97.25238715277777 L195.0 128.50238715277777 Z M205.9375 131.62738715277777 C203.34375005215406 131.62738715277777 201.25 129.5336371006237 201.25 126.93988715277777 C201.25 124.34613720493184 203.34375023841858 122.25238715277777 205.9375 122.25238715277777 C208.53124976158142 122.25238715277777 210.625 124.34613720493184 210.625 126.93988715277777 C210.625 129.5336371006237 208.53124976158142 131.62738715277777 205.9375 131.62738715277777 Z M234.0625 131.62738715277777 C231.46875005215406 131.62738715277777 229.375 129.5336371006237 229.375 126.93988715277777 C229.375 124.34613720493184 231.46875005215406 122.25238715277777 234.0625 122.25238715277777 C236.65624994784594 122.25238715277777 238.75 124.34613720493184 238.75 126.93988715277777 C238.75 129.5336371006237 236.65624994784594 131.62738715277777 234.0625 131.62738715277777 Z M238.75 112.87738715277777 L201.25 112.87738715277777 L201.25 97.25238715277777 L238.75 97.25238715277777 L238.75 112.87738715277777 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_5-87a3a" fill="#434343" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_6" class="path firer commentable non-processed" customid="Train"   datasizewidth="50.0px" datasizeheight="59.4px" dataX="275.0" dataY="84.8"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="50.0" height="59.375" viewBox="274.9999999999998 84.75238715277779 50.0 59.375" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_6-87a3a" d="M299.9999999999998 84.75238715277779 C287.4999999999998 84.75238715277779 274.9999999999998 86.31488715277779 274.9999999999998 97.25238715277779 L274.9999999999998 126.93988715277779 C274.9999999999998 132.9711381064521 279.9062505364416 137.87738715277777 285.9374999999998 137.87738715277777 L281.2499999999998 142.56488715277777 L281.2499999999998 144.12738715277777 L288.2187500596044 144.12738715277777 L294.4687500596044 137.87738715277777 L306.2499999999998 137.87738715277777 L312.4999999999998 144.12738715277777 L318.7499999999998 144.12738715277777 L318.7499999999998 142.56488715277777 L314.0624999999998 137.87738715277777 C320.093749836087 137.87738715277777 324.9999999999998 132.971136988865 324.9999999999998 126.93988715277779 L324.9999999999998 97.25238715277779 C324.9999999999998 86.31488715277779 313.81250023841835 84.75238715277779 299.9999999999998 84.75238715277779 Z M285.9374999999998 131.62738715277777 C283.34375005215384 131.62738715277777 281.2499999999998 129.5336371006237 281.2499999999998 126.93988715277779 C281.2499999999998 124.34613720493185 283.34375023841835 122.25238715277779 285.9374999999998 122.25238715277779 C288.5312497615812 122.25238715277779 290.6249999999998 124.34613720493185 290.6249999999998 126.93988715277779 C290.6249999999998 129.5336371006237 288.5312497615812 131.62738715277777 285.9374999999998 131.62738715277777 Z M296.8749999999998 109.75238715277779 L281.2499999999998 109.75238715277779 L281.2499999999998 97.25238715277779 L296.8749999999998 97.25238715277779 L296.8749999999998 109.75238715277779 Z M303.1249999999998 109.75238715277779 L303.1249999999998 97.25238715277779 L318.7499999999998 97.25238715277779 L318.7499999999998 109.75238715277779 L303.1249999999998 109.75238715277779 Z M314.0624999999998 131.62738715277777 C311.46875005215384 131.62738715277777 309.3749999999998 129.5336371006237 309.3749999999998 126.93988715277779 C309.3749999999998 124.34613720493185 311.46875005215384 122.25238715277779 314.0624999999998 122.25238715277779 C316.6562499478457 122.25238715277779 318.7499999999998 124.34613720493185 318.7499999999998 126.93988715277779 C318.7499999999998 129.5336371006237 316.6562499478457 131.62738715277777 314.0624999999998 131.62738715277777 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_6-87a3a" fill="#434343" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_8" class="group firer ie-background commentable hidden non-processed" customid="popup eliminar" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_8" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 5"   datasizewidth="275.0px" datasizeheight="246.0px" datasizewidthpx="275.00000000000006" datasizeheightpx="245.99999999999994" dataX="42.5" dataY="177.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_8_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_7" class="richtext manualfit firer click commentable non-processed" customid="No"   datasizewidth="139.8px" datasizeheight="63.8px" dataX="177.7" dataY="359.2" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_7_0">No</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_8" class="richtext manualfit firer ie-background commentable non-processed" customid="&iquest;Desea eliminar la ruta?"   datasizewidth="275.0px" datasizeheight="185.5px" dataX="42.5" dataY="177.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_8_0">&iquest;Desea eliminar la ruta?</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_9" class="richtext manualfit firer click commentable non-processed" customid="Si"   datasizewidth="139.5px" datasizeheight="63.5px" dataX="42.5" dataY="359.2" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_9_0">Si</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_1" class="group firer ie-background commentable hidden non-processed" customid="popup guardar" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 5"   datasizewidth="275.0px" datasizeheight="246.0px" datasizewidthpx="275.00000000000006" datasizeheightpx="245.99999999999994" dataX="42.6" dataY="237.6" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_1_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_1" class="richtext manualfit firer ie-background commentable non-processed" customid="Ruta actualizada"   datasizewidth="275.0px" datasizeheight="245.5px" dataX="42.6" dataY="237.6" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_1_0">Ruta <br />actualizada</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="top" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="BG - optional"   datasizewidth="360.0px" datasizeheight="69.0px" datasizewidthpx="360.00000000000045" datasizeheightpx="68.99999999999997" dataX="-0.0" dataY="-0.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_2_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_1" class="path firer commentable non-processed" customid="Account_circle"   datasizewidth="50.0px" datasizeheight="50.0px" dataX="300.0" dataY="10.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="50.0" height="50.0" viewBox="300.0000000000002 9.999999999999572 50.0 50.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_1-87a3a" d="M325.0000000000002 9.999999999999572 C311.20000004768394 9.999999999999572 300.0000000000002 21.200000047683286 300.0000000000002 34.99999999999957 C300.0000000000002 48.79999995231585 311.20000004768394 59.99999999999957 325.0000000000002 59.99999999999957 C338.7999999523165 59.99999999999957 350.0000000000002 48.79999995231585 350.0000000000002 34.99999999999957 C350.0000000000002 21.200000047683286 338.8000011444094 9.999999999999572 325.0000000000002 9.999999999999572 Z M325.0000000000002 17.49999999999957 C329.1499999165537 17.49999999999957 332.5000000000002 20.850000083446073 332.5000000000002 24.999999999999567 C332.5000000000002 29.149999916553064 329.1499999165537 32.49999999999957 325.0000000000002 32.49999999999957 C320.85000008344673 32.49999999999957 317.5000000000002 29.149999916553064 317.5000000000002 24.999999999999567 C317.5000000000002 20.850000083446073 320.85000008344673 17.49999999999957 325.0000000000002 17.49999999999957 Z M325.0000000000002 52.99999952316241 C318.7500000000002 52.99999952316241 313.2249999046328 49.79999959468798 310.0000000000002 44.949999451636835 C310.07499999832385 39.97499942779498 320.0000000000002 37.24999964237169 325.0000000000002 37.24999964237169 C329.9750000238421 37.24999964237169 339.92499947547935 39.9749997258182 340.0000000000002 44.949999451636835 C336.77500009536766 49.79999959468798 331.2500000000002 52.99999952316241 325.0000000000002 52.99999952316241 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-87a3a" fill="#EFEFEF" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_2" class="richtext manualfit firer ie-background commentable non-processed" customid="Crear ruta"   datasizewidth="240.0px" datasizeheight="69.0px" dataX="60.0" dataY="-0.5" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_2_0">Crear ruta</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_2" class="path firer commentable non-processed" customid="Home"   datasizewidth="50.0px" datasizeheight="48.0px" dataX="10.0" dataY="10.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="50.0" height="48.0" viewBox="10.0 10.00000000000017 50.0 48.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_2-87a3a" d="M30.0 58.00000000000017 L30.0 41.05882352941194 L40.0 41.05882352941194 L40.0 58.00000000000017 L52.5 58.00000000000017 L52.5 35.41176470588253 L60.0 35.41176470588253 L35.0 10.00000000000017 L10.0 35.41176470588253 L17.5 35.41176470588253 L17.5 58.00000000000017 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-87a3a" fill="#EFEFEF" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Hotspot_1" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 2"   datasizewidth="71.0px" datasizeheight="69.0px" dataX="-0.0" dataY="0.0"  >\
          <div class="clickableSpot"></div>\
        </div>\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;