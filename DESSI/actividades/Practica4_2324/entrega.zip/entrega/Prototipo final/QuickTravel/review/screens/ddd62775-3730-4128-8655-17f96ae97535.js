var content='<div class="ui-page " deviceName="androidphone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devAndroid android-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1707248953625.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-ddd62775-3730-4128-8655-17f96ae97535" class="screen growth-vertical devMobile devAndroid android-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="menu - ver mis rutas"width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/ddd62775-3730-4128-8655-17f96ae97535-1707248953625.css" />\
      <div class="freeLayout">\
      <div id="s-Group_5" class="group firer ie-background commentable non-processed" customid="Siguiente" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_4" class="rectangle manualfit firer commentable non-processed" customid="BG - optional"   datasizewidth="360.0px" datasizeheight="68.0px" datasizewidthpx="360.00000000000017" datasizeheightpx="68.0" dataX="0.0" dataY="572.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_4_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_5" class="path firer ie-background commentable non-processed" customid="Line 1"   datasizewidth="362.0px" datasizeheight="3.0px" dataX="-0.5" dataY="571.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="361.0005798339844" height="2.2036337852478027" viewBox="-0.5002822875971162 571.0000001192097 361.0005798339844 2.2036337852478027" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_5-ddd62" d="M2.8421709430404007E-13 572.0000000000001 L360.00000000000057 572.2036338912174 "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_5-ddd62" fill="none" stroke-width="1.0" stroke="#3F51B5" stroke-linecap="butt"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_71" class="path firer commentable non-processed" customid="Chevron Rigth"   datasizewidth="24.4px" datasizeheight="39.5px" dataX="325.6" dataY="586.2"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="24.40999984741211" height="39.530364990234375" viewBox="325.5900001525881 586.2348175303109 24.40999984741211 39.530364990234375" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_71-ddd62" d="M330.2348175303106 586.2348175303109 L325.5900001525881 590.8796349080334 L340.6774225197906 606.0000000000003 L325.5900001525881 621.1203650919673 L330.2348175303106 625.7651824696898 L350.0000000000002 606.0000000000003 L330.2348175303106 586.2348175303109 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_71-ddd62" fill="#3F51B5" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_13" class="richtext manualfit firer ie-background commentable non-processed" customid="Siguiente"   datasizewidth="170.9px" datasizeheight="68.0px" dataX="189.1" dataY="572.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_13_0">Siguiente &nbsp; &nbsp;</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Hotspot_2" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 2"   datasizewidth="180.0px" datasizeheight="68.0px" dataX="180.0" dataY="572.0"  >\
          <div class="clickableSpot"></div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_4" class="group firer ie-background commentable non-processed" customid="area" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Group_3" class="group firer ie-background commentable non-processed" customid="radio buttons" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Input_8" class="inputAndroid radiobutton firer commentable non-processed checked" customid="Radio button 1"  datasizewidth="30.0px" datasizeheight="30.0px" dataX="269.0" dataY="215.0"  name="s-Group_4" value="true"  checked="checked" tabindex="-1" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
          </div>\
          <div id="s-Input_1" class="inputAndroid radiobutton firer commentable non-processed unchecked" customid="Radio button 1"  datasizewidth="30.0px" datasizeheight="30.0px" dataX="269.0" dataY="275.0"  name="s-Group_4"    tabindex="-1" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
          </div>\
          <div id="s-Input_2" class="inputAndroid radiobutton firer commentable non-processed unchecked" customid="Radio button 1"  datasizewidth="30.0px" datasizeheight="30.0px" dataX="269.0" dataY="335.0"  name="s-Group_4"    tabindex="-1" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
          </div>\
          <div id="s-Input_3" class="inputAndroid radiobutton firer commentable non-processed unchecked" customid="Radio button 1"  datasizewidth="30.0px" datasizeheight="30.0px" dataX="269.0" dataY="395.0"  name="s-Group_4"    tabindex="-1" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Paragraph_12" class="richtext autofit firer ie-background commentable non-processed" customid="Nombre ruta 4"   datasizewidth="191.7px" datasizeheight="34.0px" dataX="52.4" dataY="393.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_12_0">Nombre ruta 4</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_11" class="richtext autofit firer ie-background commentable non-processed" customid="Nombre ruta 3"   datasizewidth="191.7px" datasizeheight="34.0px" dataX="52.4" dataY="333.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_11_0">Nombre ruta 3</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_10" class="richtext autofit firer ie-background commentable non-processed" customid="Nombre ruta 2"   datasizewidth="191.7px" datasizeheight="34.0px" dataX="52.4" dataY="273.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_10_0">Nombre ruta 2</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_9" class="richtext autofit firer ie-background commentable non-processed" customid="Nombre ruta 1"   datasizewidth="191.7px" datasizeheight="34.0px" dataX="52.4" dataY="213.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_9_0">Nombre ruta 1</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Line_1" class="path firer ie-background commentable non-processed" customid="Line 1"   datasizewidth="311.4px" datasizeheight="3.0px" dataX="24.9" dataY="161.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="310.3797302246094" height="2.7036314010620117" viewBox="24.888999938966073 161.00000131130267 310.3797302246094 2.7036314010620117" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Line_1-ddd62" d="M25.390136718751137 162.00000000000034 L334.76757812500125 162.70363389121738 "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Line_1-ddd62" fill="none" stroke-width="1.0" stroke="#434343" stroke-linecap="butt"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_8" class="richtext autofit firer ie-background commentable non-processed" customid="Seleccione una ruta"   datasizewidth="309.4px" datasizeheight="40.0px" dataX="25.4" dataY="122.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_8_0">Seleccione una ruta</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_1" class="group firer ie-background commentable hidden non-processed" customid="Menu" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="200.0px" datasizeheight="307.0px" datasizewidthpx="199.9999999999999" datasizeheightpx="307.00000000000017" dataX="160.0" dataY="69.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_1_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_1" class="path firer commentable non-processed" customid="Exit"   datasizewidth="25.0px" datasizeheight="25.0px" dataX="303.5" dataY="342.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="25.0" height="25.0" viewBox="303.4999999999993 342.0000000000008 25.0 25.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_1-ddd62" d="M313.34722243414916 359.48611132303955 L315.30555555555486 361.44444444444525 L322.2499999999993 354.5000000000008 L315.30555555555486 347.55555555555634 L313.3472222685807 349.5138888425305 L316.93055566151867 353.1111111111119 L303.4999999999993 353.1111111111119 L303.4999999999993 355.8888888888897 L316.93055566151867 355.8888888888897 L313.34722243414916 359.4861109919026 Z M325.72222222222155 342.0000000000008 L306.2777777777771 342.0000000000008 C304.7361110912422 342.0000000000008 303.4999999999993 343.2499999668871 303.4999999999993 344.77777777777857 L303.4999999999993 350.3333333333341 L306.2777777777771 350.3333333333341 L306.2777777777771 344.77777777777857 L325.72222222222155 344.77777777777857 L325.72222222222155 364.222222222223 L306.2777777777771 364.222222222223 L306.2777777777771 358.6666666666675 L303.4999999999993 358.6666666666675 L303.4999999999993 364.222222222223 C303.4999999999993 365.7500000331145 304.7361110912422 367.0000000000008 306.2777777777771 367.0000000000008 L325.72222222222155 367.0000000000008 C327.250000033113 367.0000000000008 328.4999999999993 365.7500000331145 328.4999999999993 364.222222222223 L328.4999999999993 344.77777777777857 C328.4999999999993 343.2499999668871 327.250000033113 342.0000000000008 325.72222222222155 342.0000000000008 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-ddd62" fill="#434343" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_1" class="richtext manualfit firer click ie-background commentable non-processed" customid="Salir"   datasizewidth="200.0px" datasizeheight="48.0px" dataX="160.0" dataY="328.3" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_1_0">Salir</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_2" class="richtext manualfit firer click ie-background commentable non-processed" customid="Mis rutas (U)"   datasizewidth="200.0px" datasizeheight="48.0px" dataX="160.0" dataY="233.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_2_0">Mis rutas (U)</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_3" class="richtext manualfit firer click ie-background commentable non-processed" customid="Perfil (L)"   datasizewidth="200.0px" datasizeheight="48.0px" dataX="160.0" dataY="185.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_3_0">Perfil (L)</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_4" class="richtext manualfit firer click ie-background commentable non-processed" customid="Perfil (U)"   datasizewidth="200.0px" datasizeheight="48.0px" dataX="160.0" dataY="137.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_4_0">Perfil (U)</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_2" class="path firer commentable non-processed" customid="Clear"   datasizewidth="31.0px" datasizeheight="31.0px" dataX="180.0" dataY="88.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="31.0" height="31.0" viewBox="180.00000000000026 88.0 31.0 31.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_2-ddd62" d="M211.00000000000026 91.12214251926969 L207.87785748073057 88.0 L195.50000000000026 100.37785748073037 L183.12214251926991 88.0 L180.00000000000026 91.12214251926969 L192.3778574807306 103.50000000000006 L180.00000000000026 115.87785748073046 L183.12214251926991 119.00000000000013 L195.50000000000026 106.62214251926974 L207.87785748073057 119.00000000000013 L211.00000000000026 115.87785748073046 L198.62214251926991 103.50000000000006 L211.00000000000026 91.12214251926969 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-ddd62" fill="#434343" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Hotspot_3" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 1"   datasizewidth="71.0px" datasizeheight="68.4px" dataX="160.0" dataY="69.0"  >\
          <div class="clickableSpot"></div>\
        </div>\
        <div id="s-Paragraph_5" class="richtext manualfit firer ie-background commentable non-processed" customid="Menu"   datasizewidth="139.0px" datasizeheight="68.0px" dataX="221.0" dataY="69.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_5_0">Menu</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_6" class="richtext manualfit firer ie-background commentable non-processed" customid="..."   datasizewidth="200.0px" datasizeheight="48.0px" dataX="160.0" dataY="280.2" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_6_0">...</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="top" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="BG - optional"   datasizewidth="360.0px" datasizeheight="69.0px" datasizewidthpx="360.00000000000045" datasizeheightpx="68.99999999999997" dataX="-0.0" dataY="-0.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_2_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_3" class="path firer click commentable non-processed" customid="Account_circle"   datasizewidth="50.0px" datasizeheight="50.0px" dataX="300.0" dataY="10.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="50.0" height="50.0" viewBox="300.0000000000002 9.999999999999572 50.0 50.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_3-ddd62" d="M325.0000000000002 9.999999999999572 C311.20000004768394 9.999999999999572 300.0000000000002 21.200000047683286 300.0000000000002 34.99999999999957 C300.0000000000002 48.79999995231585 311.20000004768394 59.99999999999957 325.0000000000002 59.99999999999957 C338.7999999523165 59.99999999999957 350.0000000000002 48.79999995231585 350.0000000000002 34.99999999999957 C350.0000000000002 21.200000047683286 338.8000011444094 9.999999999999572 325.0000000000002 9.999999999999572 Z M325.0000000000002 17.49999999999957 C329.1499999165537 17.49999999999957 332.5000000000002 20.850000083446073 332.5000000000002 24.999999999999567 C332.5000000000002 29.149999916553064 329.1499999165537 32.49999999999957 325.0000000000002 32.49999999999957 C320.85000008344673 32.49999999999957 317.5000000000002 29.149999916553064 317.5000000000002 24.999999999999567 C317.5000000000002 20.850000083446073 320.85000008344673 17.49999999999957 325.0000000000002 17.49999999999957 Z M325.0000000000002 52.99999952316241 C318.7500000000002 52.99999952316241 313.2249999046328 49.79999959468798 310.0000000000002 44.949999451636835 C310.07499999832385 39.97499942779498 320.0000000000002 37.24999964237169 325.0000000000002 37.24999964237169 C329.9750000238421 37.24999964237169 339.92499947547935 39.9749997258182 340.0000000000002 44.949999451636835 C336.77500009536766 49.79999959468798 331.2500000000002 52.99999952316241 325.0000000000002 52.99999952316241 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_3-ddd62" fill="#EFEFEF" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_7" class="richtext manualfit firer ie-background commentable non-processed" customid="Mis rutas"   datasizewidth="240.0px" datasizeheight="69.0px" dataX="60.0" dataY="-0.5" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_7_0">Mis rutas</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_4" class="path firer commentable non-processed" customid="Home"   datasizewidth="50.0px" datasizeheight="48.0px" dataX="10.0" dataY="10.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="50.0" height="48.0" viewBox="10.0 10.00000000000017 50.0 48.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_4-ddd62" d="M30.0 58.00000000000017 L30.0 41.05882352941194 L40.0 41.05882352941194 L40.0 58.00000000000017 L52.5 58.00000000000017 L52.5 35.41176470588253 L60.0 35.41176470588253 L35.0 10.00000000000017 L10.0 35.41176470588253 L17.5 35.41176470588253 L17.5 58.00000000000017 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_4-ddd62" fill="#EFEFEF" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Hotspot_4" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 2"   datasizewidth="71.0px" datasizeheight="69.0px" dataX="-0.0" dataY="0.0"  >\
          <div class="clickableSpot"></div>\
        </div>\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;