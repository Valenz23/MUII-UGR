	window.widgets = {
		descriptionMap : widgetDescriptionMap = {},
		rootWidgetMap : widgetRootMap = {}
	};

	widgets.descriptionMap[["s-Path_4", "02e86551-4e38-4404-8e4f-81367399085d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "02e86551-4e38-4404-8e4f-81367399085d"]] = ["Chevron rigth", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_129", "02e86551-4e38-4404-8e4f-81367399085d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_129", "02e86551-4e38-4404-8e4f-81367399085d"]] = ["Location on", "s-Path_129"]; 

	widgets.descriptionMap[["s-Path_258", "02e86551-4e38-4404-8e4f-81367399085d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_258", "02e86551-4e38-4404-8e4f-81367399085d"]] = ["Location fixed", "s-Path_258"]; 

	widgets.descriptionMap[["s-Path_1", "02e86551-4e38-4404-8e4f-81367399085d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "02e86551-4e38-4404-8e4f-81367399085d"]] = ["Account circle", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "02e86551-4e38-4404-8e4f-81367399085d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "02e86551-4e38-4404-8e4f-81367399085d"]] = ["Home", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_11", "e4a7ac8c-d008-465a-a5ba-dad5ef0f4d6d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "e4a7ac8c-d008-465a-a5ba-dad5ef0f4d6d"]] = ["Location on", "s-Path_11"]; 

	widgets.descriptionMap[["s-Path_2", "e4a7ac8c-d008-465a-a5ba-dad5ef0f4d6d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "e4a7ac8c-d008-465a-a5ba-dad5ef0f4d6d"]] = ["Location on", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_3", "e4a7ac8c-d008-465a-a5ba-dad5ef0f4d6d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "e4a7ac8c-d008-465a-a5ba-dad5ef0f4d6d"]] = ["Location on", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_4", "e4a7ac8c-d008-465a-a5ba-dad5ef0f4d6d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "e4a7ac8c-d008-465a-a5ba-dad5ef0f4d6d"]] = ["Location on", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_5", "e4a7ac8c-d008-465a-a5ba-dad5ef0f4d6d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "e4a7ac8c-d008-465a-a5ba-dad5ef0f4d6d"]] = ["Location on", "s-Path_5"]; 

	widgets.descriptionMap[["s-Path_106", "e4a7ac8c-d008-465a-a5ba-dad5ef0f4d6d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_106", "e4a7ac8c-d008-465a-a5ba-dad5ef0f4d6d"]] = ["Exit", "s-Path_106"]; 

	widgets.descriptionMap[["s-Path_85", "e4a7ac8c-d008-465a-a5ba-dad5ef0f4d6d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_85", "e4a7ac8c-d008-465a-a5ba-dad5ef0f4d6d"]] = ["Clear", "s-Path_85"]; 

	widgets.descriptionMap[["s-Input_1", "e4a7ac8c-d008-465a-a5ba-dad5ef0f4d6d"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "e4a7ac8c-d008-465a-a5ba-dad5ef0f4d6d"]] = ["Search", "s-Group_2"]; 

	widgets.descriptionMap[["s-Path_1", "e4a7ac8c-d008-465a-a5ba-dad5ef0f4d6d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "e4a7ac8c-d008-465a-a5ba-dad5ef0f4d6d"]] = ["Search", "s-Group_2"]; 

	widgets.descriptionMap[["s-Path_8", "e4a7ac8c-d008-465a-a5ba-dad5ef0f4d6d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "e4a7ac8c-d008-465a-a5ba-dad5ef0f4d6d"]] = ["Account circle", "s-Path_8"]; 

	widgets.descriptionMap[["s-Path_6", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ["Save", "s-Path_6"]; 

	widgets.descriptionMap[["s-Path_5", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ["Chevron left", "s-Path_5"]; 

	widgets.descriptionMap[["s-Rectangle_22", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_22", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ["Dragging list", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_11", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ["Dragging list", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Paragraph_13", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_13", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ["Body large", "s-Paragraph_13"]; 

	widgets.descriptionMap[["s-Path_13", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ""; 

			widgets.rootWidgetMap[["s-Path_13", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ["Location on", "s-Path_13"]; 

	widgets.descriptionMap[["s-Hotspot_10", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_10", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ["Dragging list", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_25", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_25", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ["Dragging list", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_9", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ["Dragging list", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Paragraph_12", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_12", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ["Body large", "s-Paragraph_12"]; 

	widgets.descriptionMap[["s-Path_10", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ["Location on", "s-Path_10"]; 

	widgets.descriptionMap[["s-Hotspot_11", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_11", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ["Dragging list", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_28", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_28", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ["Dragging list", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_7", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ["Dragging list", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Paragraph_11", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_11", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ["Body large", "s-Paragraph_11"]; 

	widgets.descriptionMap[["s-Path_8", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ["Location on", "s-Path_8"]; 

	widgets.descriptionMap[["s-Hotspot_12", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_12", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ["Dragging list", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_31", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_31", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ["Dragging list", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_15", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ""; 

			widgets.rootWidgetMap[["s-Path_15", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ["Dragging list", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Paragraph_28", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_28", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ["Body large", "s-Paragraph_28"]; 

	widgets.descriptionMap[["s-Path_129", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ""; 

			widgets.rootWidgetMap[["s-Path_129", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ["Location on", "s-Path_129"]; 

	widgets.descriptionMap[["s-Hotspot_13", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_13", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ["Dragging list", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Panel_1", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ["Dragging list", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_346", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ""; 

			widgets.rootWidgetMap[["s-Path_346", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ["Bike", "s-Path_346"]; 

	widgets.descriptionMap[["s-Path_367", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ""; 

			widgets.rootWidgetMap[["s-Path_367", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ["Car", "s-Path_367"]; 

	widgets.descriptionMap[["s-Path_352", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ""; 

			widgets.rootWidgetMap[["s-Path_352", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ["Bus", "s-Path_352"]; 

	widgets.descriptionMap[["s-Path_466", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ""; 

			widgets.rootWidgetMap[["s-Path_466", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ["Train", "s-Path_466"]; 

	widgets.descriptionMap[["s-Path_1", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ["Exit", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ["Clear", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_3", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ["Account circle", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_4", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "761e17d9-4016-42d3-86a9-92aef0fba110"]] = ["Home", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_2", "91d52cea-b132-4968-be2f-8c614f78dc4b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "91d52cea-b132-4968-be2f-8c614f78dc4b"]] = ["Search", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_75", "91d52cea-b132-4968-be2f-8c614f78dc4b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_75", "91d52cea-b132-4968-be2f-8c614f78dc4b"]] = ["Chevron left", "s-Path_75"]; 

	widgets.descriptionMap[["s-Image_1", "91d52cea-b132-4968-be2f-8c614f78dc4b"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "91d52cea-b132-4968-be2f-8c614f78dc4b"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Image_2", "91d52cea-b132-4968-be2f-8c614f78dc4b"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "91d52cea-b132-4968-be2f-8c614f78dc4b"]] = ["Image", "s-Image_2"]; 

	widgets.descriptionMap[["s-Image_3", "91d52cea-b132-4968-be2f-8c614f78dc4b"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "91d52cea-b132-4968-be2f-8c614f78dc4b"]] = ["Image", "s-Image_3"]; 

	widgets.descriptionMap[["s-Path_3", "91d52cea-b132-4968-be2f-8c614f78dc4b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "91d52cea-b132-4968-be2f-8c614f78dc4b"]] = ["Exit", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_4", "91d52cea-b132-4968-be2f-8c614f78dc4b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "91d52cea-b132-4968-be2f-8c614f78dc4b"]] = ["Clear", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_5", "91d52cea-b132-4968-be2f-8c614f78dc4b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "91d52cea-b132-4968-be2f-8c614f78dc4b"]] = ["Account circle", "s-Path_5"]; 

	widgets.descriptionMap[["s-Path_6", "91d52cea-b132-4968-be2f-8c614f78dc4b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "91d52cea-b132-4968-be2f-8c614f78dc4b"]] = ["Home", "s-Path_6"]; 

	widgets.descriptionMap[["s-Path_7", "76775d35-8df5-4014-b952-059d98a7145b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "76775d35-8df5-4014-b952-059d98a7145b"]] = ["Chevron left", "s-Path_7"]; 

	widgets.descriptionMap[["s-Path_4", "76775d35-8df5-4014-b952-059d98a7145b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "76775d35-8df5-4014-b952-059d98a7145b"]] = ["Chevron rigth", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_1", "76775d35-8df5-4014-b952-059d98a7145b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "76775d35-8df5-4014-b952-059d98a7145b"]] = ["Account circle", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "76775d35-8df5-4014-b952-059d98a7145b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "76775d35-8df5-4014-b952-059d98a7145b"]] = ["Home", "s-Path_2"]; 

	widgets.descriptionMap[["s-Button_1", "1babc1b0-ad6d-49e7-a540-677bde277f9b"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "1babc1b0-ad6d-49e7-a540-677bde277f9b"]] = ["Filled button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Path_1", "1babc1b0-ad6d-49e7-a540-677bde277f9b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "1babc1b0-ad6d-49e7-a540-677bde277f9b"]] = ["Exit", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "1babc1b0-ad6d-49e7-a540-677bde277f9b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "1babc1b0-ad6d-49e7-a540-677bde277f9b"]] = ["Clear", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_3", "1babc1b0-ad6d-49e7-a540-677bde277f9b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "1babc1b0-ad6d-49e7-a540-677bde277f9b"]] = ["Account circle", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_4", "1babc1b0-ad6d-49e7-a540-677bde277f9b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "1babc1b0-ad6d-49e7-a540-677bde277f9b"]] = ["Home", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_274", "bd48995b-8bc6-4d41-8fab-7b7e7c5cc426"]] = ""; 

			widgets.rootWidgetMap[["s-Path_274", "bd48995b-8bc6-4d41-8fab-7b7e7c5cc426"]] = ["Location add", "s-Path_274"]; 

	widgets.descriptionMap[["s-Path_42", "bd48995b-8bc6-4d41-8fab-7b7e7c5cc426"]] = ""; 

			widgets.rootWidgetMap[["s-Path_42", "bd48995b-8bc6-4d41-8fab-7b7e7c5cc426"]] = ["Search", "s-Path_42"]; 

	widgets.descriptionMap[["s-Image_3", "bd48995b-8bc6-4d41-8fab-7b7e7c5cc426"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "bd48995b-8bc6-4d41-8fab-7b7e7c5cc426"]] = ["Image", "s-Image_3"]; 

	widgets.descriptionMap[["s-Image_2", "bd48995b-8bc6-4d41-8fab-7b7e7c5cc426"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "bd48995b-8bc6-4d41-8fab-7b7e7c5cc426"]] = ["Image", "s-Image_2"]; 

	widgets.descriptionMap[["s-Image", "bd48995b-8bc6-4d41-8fab-7b7e7c5cc426"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "bd48995b-8bc6-4d41-8fab-7b7e7c5cc426"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Path_1", "bd48995b-8bc6-4d41-8fab-7b7e7c5cc426"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "bd48995b-8bc6-4d41-8fab-7b7e7c5cc426"]] = ["Exit", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "bd48995b-8bc6-4d41-8fab-7b7e7c5cc426"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "bd48995b-8bc6-4d41-8fab-7b7e7c5cc426"]] = ["Clear", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_3", "bd48995b-8bc6-4d41-8fab-7b7e7c5cc426"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "bd48995b-8bc6-4d41-8fab-7b7e7c5cc426"]] = ["Account circle", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_4", "bd48995b-8bc6-4d41-8fab-7b7e7c5cc426"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "bd48995b-8bc6-4d41-8fab-7b7e7c5cc426"]] = ["Home", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_199", "6c461711-eacb-4ed1-b333-9b819cab482e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_199", "6c461711-eacb-4ed1-b333-9b819cab482e"]] = ["Add circle", "s-Path_199"]; 

	widgets.descriptionMap[["s-Path_350", "6c461711-eacb-4ed1-b333-9b819cab482e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_350", "6c461711-eacb-4ed1-b333-9b819cab482e"]] = ["User outline", "s-Path_350"]; 

	widgets.descriptionMap[["s-Path_5", "6c461711-eacb-4ed1-b333-9b819cab482e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "6c461711-eacb-4ed1-b333-9b819cab482e"]] = ["User outline", "s-Path_5"]; 

	widgets.descriptionMap[["s-Path_6", "6c461711-eacb-4ed1-b333-9b819cab482e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "6c461711-eacb-4ed1-b333-9b819cab482e"]] = ["User outline", "s-Path_6"]; 

	widgets.descriptionMap[["s-Path_1", "6c461711-eacb-4ed1-b333-9b819cab482e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "6c461711-eacb-4ed1-b333-9b819cab482e"]] = ["Exit", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "6c461711-eacb-4ed1-b333-9b819cab482e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "6c461711-eacb-4ed1-b333-9b819cab482e"]] = ["Clear", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_3", "6c461711-eacb-4ed1-b333-9b819cab482e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "6c461711-eacb-4ed1-b333-9b819cab482e"]] = ["Account circle", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_4", "6c461711-eacb-4ed1-b333-9b819cab482e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "6c461711-eacb-4ed1-b333-9b819cab482e"]] = ["Home", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_16", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ""; 

			widgets.rootWidgetMap[["s-Path_16", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ["Save", "s-Path_16"]; 

	widgets.descriptionMap[["s-Path_17", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ""; 

			widgets.rootWidgetMap[["s-Path_17", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ["Chevron left", "s-Path_17"]; 

	widgets.descriptionMap[["s-Rectangle_4", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ["Dragging list", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_7", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ["Dragging list", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Paragraph_3", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ["Body large", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Path_8", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ["Location on", "s-Path_8"]; 

	widgets.descriptionMap[["s-Hotspot_2", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_2", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ["Dragging list", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_5", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ["Dragging list", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_9", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ["Dragging list", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Paragraph_4", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ["Body large", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Path_10", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ["Location on", "s-Path_10"]; 

	widgets.descriptionMap[["s-Hotspot_3", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_3", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ["Dragging list", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_6", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ["Dragging list", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_11", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ["Dragging list", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Paragraph_5", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ["Body large", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Path_12", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ""; 

			widgets.rootWidgetMap[["s-Path_12", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ["Location on", "s-Path_12"]; 

	widgets.descriptionMap[["s-Hotspot_4", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_4", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ["Dragging list", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Rectangle_7", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_7", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ["Dragging list", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_13", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ""; 

			widgets.rootWidgetMap[["s-Path_13", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ["Dragging list", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Paragraph_6", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ["Body large", "s-Paragraph_6"]; 

	widgets.descriptionMap[["s-Path_14", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ""; 

			widgets.rootWidgetMap[["s-Path_14", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ["Location on", "s-Path_14"]; 

	widgets.descriptionMap[["s-Hotspot_5", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ""; 

			widgets.rootWidgetMap[["s-Hotspot_5", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ["Dragging list", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Panel_1", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ["Dragging list", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_3", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ["Bike", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_4", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ["Car", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_5", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ["Bus", "s-Path_5"]; 

	widgets.descriptionMap[["s-Path_6", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ["Train", "s-Path_6"]; 

	widgets.descriptionMap[["s-Path_1", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ["Account circle", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "87a3a7ab-b815-47eb-a4f8-41f692128f10"]] = ["Home", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_214", "a9728240-1718-464b-a2dd-56afe2f18758"]] = ""; 

			widgets.rootWidgetMap[["s-Path_214", "a9728240-1718-464b-a2dd-56afe2f18758"]] = ["Save", "s-Path_214"]; 

	widgets.descriptionMap[["s-Path_75", "a9728240-1718-464b-a2dd-56afe2f18758"]] = ""; 

			widgets.rootWidgetMap[["s-Path_75", "a9728240-1718-464b-a2dd-56afe2f18758"]] = ["Chevron left", "s-Path_75"]; 

	widgets.descriptionMap[["s-Path_153", "a9728240-1718-464b-a2dd-56afe2f18758"]] = ""; 

			widgets.rootWidgetMap[["s-Path_153", "a9728240-1718-464b-a2dd-56afe2f18758"]] = ["More horizontal", "s-Path_153"]; 

	widgets.descriptionMap[["s-Path_59", "a9728240-1718-464b-a2dd-56afe2f18758"]] = ""; 

			widgets.rootWidgetMap[["s-Path_59", "a9728240-1718-464b-a2dd-56afe2f18758"]] = ["Delete", "s-Path_59"]; 

	widgets.descriptionMap[["s-Path_5", "a9728240-1718-464b-a2dd-56afe2f18758"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "a9728240-1718-464b-a2dd-56afe2f18758"]] = ["Location on", "s-Path_5"]; 

	widgets.descriptionMap[["s-Path_7", "a9728240-1718-464b-a2dd-56afe2f18758"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "a9728240-1718-464b-a2dd-56afe2f18758"]] = ["Location on", "s-Path_7"]; 

	widgets.descriptionMap[["s-Path_8", "a9728240-1718-464b-a2dd-56afe2f18758"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "a9728240-1718-464b-a2dd-56afe2f18758"]] = ["Location on", "s-Path_8"]; 

	widgets.descriptionMap[["s-Path_9", "a9728240-1718-464b-a2dd-56afe2f18758"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "a9728240-1718-464b-a2dd-56afe2f18758"]] = ["Location on", "s-Path_9"]; 

	widgets.descriptionMap[["s-Path_10", "a9728240-1718-464b-a2dd-56afe2f18758"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "a9728240-1718-464b-a2dd-56afe2f18758"]] = ["Location on", "s-Path_10"]; 

	widgets.descriptionMap[["s-Path_1", "a9728240-1718-464b-a2dd-56afe2f18758"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "a9728240-1718-464b-a2dd-56afe2f18758"]] = ["Exit", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "a9728240-1718-464b-a2dd-56afe2f18758"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "a9728240-1718-464b-a2dd-56afe2f18758"]] = ["Clear", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_3", "a9728240-1718-464b-a2dd-56afe2f18758"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "a9728240-1718-464b-a2dd-56afe2f18758"]] = ["Account circle", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_4", "a9728240-1718-464b-a2dd-56afe2f18758"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "a9728240-1718-464b-a2dd-56afe2f18758"]] = ["Home", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_129", "2d9938d3-2b8b-4744-9266-62aa86841c4d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_129", "2d9938d3-2b8b-4744-9266-62aa86841c4d"]] = ["Location on", "s-Path_129"]; 

	widgets.descriptionMap[["s-Path_99", "2d9938d3-2b8b-4744-9266-62aa86841c4d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_99", "2d9938d3-2b8b-4744-9266-62aa86841c4d"]] = ["Done", "s-Path_99"]; 

	widgets.descriptionMap[["s-Path_3", "2d9938d3-2b8b-4744-9266-62aa86841c4d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "2d9938d3-2b8b-4744-9266-62aa86841c4d"]] = ["Location on", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_4", "2d9938d3-2b8b-4744-9266-62aa86841c4d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "2d9938d3-2b8b-4744-9266-62aa86841c4d"]] = ["Location on", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_5", "2d9938d3-2b8b-4744-9266-62aa86841c4d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "2d9938d3-2b8b-4744-9266-62aa86841c4d"]] = ["Location on", "s-Path_5"]; 

	widgets.descriptionMap[["s-Path_6", "2d9938d3-2b8b-4744-9266-62aa86841c4d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "2d9938d3-2b8b-4744-9266-62aa86841c4d"]] = ["Location on", "s-Path_6"]; 

	widgets.descriptionMap[["s-Path_7", "2d9938d3-2b8b-4744-9266-62aa86841c4d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "2d9938d3-2b8b-4744-9266-62aa86841c4d"]] = ["Location on", "s-Path_7"]; 

	widgets.descriptionMap[["s-Input_1", "2d9938d3-2b8b-4744-9266-62aa86841c4d"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "2d9938d3-2b8b-4744-9266-62aa86841c4d"]] = ["Search", "s-Group_3"]; 

	widgets.descriptionMap[["s-Path_1", "2d9938d3-2b8b-4744-9266-62aa86841c4d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "2d9938d3-2b8b-4744-9266-62aa86841c4d"]] = ["Search", "s-Group_3"]; 

	widgets.descriptionMap[["s-Path_2", "2d9938d3-2b8b-4744-9266-62aa86841c4d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "2d9938d3-2b8b-4744-9266-62aa86841c4d"]] = ["Account circle", "s-Path_2"]; 

	widgets.descriptionMap[["s-Input_2", "2d9938d3-2b8b-4744-9266-62aa86841c4d"]] = ""; 

			widgets.rootWidgetMap[["s-Input_2", "2d9938d3-2b8b-4744-9266-62aa86841c4d"]] = ["Search", "s-Group_6"]; 

	widgets.descriptionMap[["s-Path_10", "2d9938d3-2b8b-4744-9266-62aa86841c4d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "2d9938d3-2b8b-4744-9266-62aa86841c4d"]] = ["Search", "s-Group_6"]; 

	widgets.descriptionMap[["s-Path_11", "2d9938d3-2b8b-4744-9266-62aa86841c4d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "2d9938d3-2b8b-4744-9266-62aa86841c4d"]] = ["Account circle", "s-Path_11"]; 

	widgets.descriptionMap[["s-Path_13", "b85dbafa-dce5-4914-9bee-803e3cc20476"]] = ""; 

			widgets.rootWidgetMap[["s-Path_13", "b85dbafa-dce5-4914-9bee-803e3cc20476"]] = ["Save", "s-Path_13"]; 

	widgets.descriptionMap[["s-Path_14", "b85dbafa-dce5-4914-9bee-803e3cc20476"]] = ""; 

			widgets.rootWidgetMap[["s-Path_14", "b85dbafa-dce5-4914-9bee-803e3cc20476"]] = ["Chevron left", "s-Path_14"]; 

	widgets.descriptionMap[["s-Path_15", "b85dbafa-dce5-4914-9bee-803e3cc20476"]] = ""; 

			widgets.rootWidgetMap[["s-Path_15", "b85dbafa-dce5-4914-9bee-803e3cc20476"]] = ["More horizontal", "s-Path_15"]; 

	widgets.descriptionMap[["s-Path_7", "b85dbafa-dce5-4914-9bee-803e3cc20476"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "b85dbafa-dce5-4914-9bee-803e3cc20476"]] = ["Location on", "s-Path_7"]; 

	widgets.descriptionMap[["s-Path_8", "b85dbafa-dce5-4914-9bee-803e3cc20476"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "b85dbafa-dce5-4914-9bee-803e3cc20476"]] = ["Location on", "s-Path_8"]; 

	widgets.descriptionMap[["s-Path_9", "b85dbafa-dce5-4914-9bee-803e3cc20476"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "b85dbafa-dce5-4914-9bee-803e3cc20476"]] = ["Location on", "s-Path_9"]; 

	widgets.descriptionMap[["s-Path_10", "b85dbafa-dce5-4914-9bee-803e3cc20476"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "b85dbafa-dce5-4914-9bee-803e3cc20476"]] = ["Location on", "s-Path_10"]; 

	widgets.descriptionMap[["s-Path_11", "b85dbafa-dce5-4914-9bee-803e3cc20476"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "b85dbafa-dce5-4914-9bee-803e3cc20476"]] = ["Location on", "s-Path_11"]; 

	widgets.descriptionMap[["s-Path_1", "b85dbafa-dce5-4914-9bee-803e3cc20476"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "b85dbafa-dce5-4914-9bee-803e3cc20476"]] = ["Account circle", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "b85dbafa-dce5-4914-9bee-803e3cc20476"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "b85dbafa-dce5-4914-9bee-803e3cc20476"]] = ["Home", "s-Path_2"]; 

	widgets.descriptionMap[["s-Image_3", "7699c6f4-e99e-4163-8b56-5383848d89df"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "7699c6f4-e99e-4163-8b56-5383848d89df"]] = ["Image", "s-Image_3"]; 

	widgets.descriptionMap[["s-Button_1", "7699c6f4-e99e-4163-8b56-5383848d89df"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "7699c6f4-e99e-4163-8b56-5383848d89df"]] = ["Filled button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Path_1", "b3e60a04-98c3-4a42-b91c-e0f5f994cc4d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "b3e60a04-98c3-4a42-b91c-e0f5f994cc4d"]] = ["Add circle", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_10", "b3e60a04-98c3-4a42-b91c-e0f5f994cc4d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "b3e60a04-98c3-4a42-b91c-e0f5f994cc4d"]] = ["Chevron left", "s-Path_10"]; 

	widgets.descriptionMap[["s-Path_2", "b3e60a04-98c3-4a42-b91c-e0f5f994cc4d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "b3e60a04-98c3-4a42-b91c-e0f5f994cc4d"]] = ["User outline", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_3", "b3e60a04-98c3-4a42-b91c-e0f5f994cc4d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "b3e60a04-98c3-4a42-b91c-e0f5f994cc4d"]] = ["User outline", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_4", "b3e60a04-98c3-4a42-b91c-e0f5f994cc4d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "b3e60a04-98c3-4a42-b91c-e0f5f994cc4d"]] = ["User outline", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_5", "b3e60a04-98c3-4a42-b91c-e0f5f994cc4d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "b3e60a04-98c3-4a42-b91c-e0f5f994cc4d"]] = ["Exit", "s-Path_5"]; 

	widgets.descriptionMap[["s-Path_6", "b3e60a04-98c3-4a42-b91c-e0f5f994cc4d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "b3e60a04-98c3-4a42-b91c-e0f5f994cc4d"]] = ["Clear", "s-Path_6"]; 

	widgets.descriptionMap[["s-Path_7", "b3e60a04-98c3-4a42-b91c-e0f5f994cc4d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "b3e60a04-98c3-4a42-b91c-e0f5f994cc4d"]] = ["Account circle", "s-Path_7"]; 

	widgets.descriptionMap[["s-Path_8", "b3e60a04-98c3-4a42-b91c-e0f5f994cc4d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "b3e60a04-98c3-4a42-b91c-e0f5f994cc4d"]] = ["Home", "s-Path_8"]; 

	widgets.descriptionMap[["s-Path_71", "ddd62775-3730-4128-8655-17f96ae97535"]] = ""; 

			widgets.rootWidgetMap[["s-Path_71", "ddd62775-3730-4128-8655-17f96ae97535"]] = ["Chevron rigth", "s-Path_71"]; 

	widgets.descriptionMap[["s-Path_1", "ddd62775-3730-4128-8655-17f96ae97535"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "ddd62775-3730-4128-8655-17f96ae97535"]] = ["Exit", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "ddd62775-3730-4128-8655-17f96ae97535"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "ddd62775-3730-4128-8655-17f96ae97535"]] = ["Clear", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_3", "ddd62775-3730-4128-8655-17f96ae97535"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "ddd62775-3730-4128-8655-17f96ae97535"]] = ["Account circle", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_4", "ddd62775-3730-4128-8655-17f96ae97535"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "ddd62775-3730-4128-8655-17f96ae97535"]] = ["Home", "s-Path_4"]; 

	widgets.descriptionMap[["s-Image_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Image", "s-Image_5"]; 

	widgets.descriptionMap[["s-Button_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Filled button", "s-Button_2"]; 

	widgets.descriptionMap[["s-Button_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Button_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Filled button", "s-Button_3"]; 

	widgets.descriptionMap[["s-Button_1", "d639823a-add8-4ab5-8c0f-1f460b7e886c"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "d639823a-add8-4ab5-8c0f-1f460b7e886c"]] = ["Filled button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Path_1", "d639823a-add8-4ab5-8c0f-1f460b7e886c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "d639823a-add8-4ab5-8c0f-1f460b7e886c"]] = ["Exit", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "d639823a-add8-4ab5-8c0f-1f460b7e886c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "d639823a-add8-4ab5-8c0f-1f460b7e886c"]] = ["Clear", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_3", "d639823a-add8-4ab5-8c0f-1f460b7e886c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "d639823a-add8-4ab5-8c0f-1f460b7e886c"]] = ["Account circle", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_72", "d639823a-add8-4ab5-8c0f-1f460b7e886c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_72", "d639823a-add8-4ab5-8c0f-1f460b7e886c"]] = ["Home", "s-Path_72"]; 

	widgets.descriptionMap[["s-Path_2", "8002115f-7bef-4df3-997f-091229ff38d6"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "8002115f-7bef-4df3-997f-091229ff38d6"]] = ["Location on", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_4", "8002115f-7bef-4df3-997f-091229ff38d6"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "8002115f-7bef-4df3-997f-091229ff38d6"]] = ["Location on", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_5", "8002115f-7bef-4df3-997f-091229ff38d6"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "8002115f-7bef-4df3-997f-091229ff38d6"]] = ["Location on", "s-Path_5"]; 

	widgets.descriptionMap[["s-Path_1", "8002115f-7bef-4df3-997f-091229ff38d6"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "8002115f-7bef-4df3-997f-091229ff38d6"]] = ["Exit", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_3", "8002115f-7bef-4df3-997f-091229ff38d6"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "8002115f-7bef-4df3-997f-091229ff38d6"]] = ["Clear", "s-Path_3"]; 

	widgets.descriptionMap[["s-Input_1", "8002115f-7bef-4df3-997f-091229ff38d6"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "8002115f-7bef-4df3-997f-091229ff38d6"]] = ["Search", "s-Group_4"]; 

	widgets.descriptionMap[["s-Path_6", "8002115f-7bef-4df3-997f-091229ff38d6"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "8002115f-7bef-4df3-997f-091229ff38d6"]] = ["Search", "s-Group_4"]; 

	widgets.descriptionMap[["s-Path_7", "8002115f-7bef-4df3-997f-091229ff38d6"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "8002115f-7bef-4df3-997f-091229ff38d6"]] = ["Account circle", "s-Path_7"]; 

	