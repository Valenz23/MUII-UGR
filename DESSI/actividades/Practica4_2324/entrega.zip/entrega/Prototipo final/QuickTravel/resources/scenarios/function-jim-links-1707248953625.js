(function(window, undefined) {

  var jimLinks = {
    "02e86551-4e38-4404-8e4f-81367399085d" : {
      "Hotspot_1" : [
        "76775d35-8df5-4014-b952-059d98a7145b"
      ],
      "Paragraph_4" : [
        "e4a7ac8c-d008-465a-a5ba-dad5ef0f4d6d"
      ]
    },
    "e4a7ac8c-d008-465a-a5ba-dad5ef0f4d6d" : {
      "Image_1" : [
        "8002115f-7bef-4df3-997f-091229ff38d6"
      ],
      "Path_11" : [
        "bd48995b-8bc6-4d41-8fab-7b7e7c5cc426"
      ],
      "Path_2" : [
        "bd48995b-8bc6-4d41-8fab-7b7e7c5cc426"
      ],
      "Path_3" : [
        "bd48995b-8bc6-4d41-8fab-7b7e7c5cc426"
      ],
      "Path_4" : [
        "bd48995b-8bc6-4d41-8fab-7b7e7c5cc426"
      ],
      "Path_5" : [
        "bd48995b-8bc6-4d41-8fab-7b7e7c5cc426"
      ],
      "Paragraph_5" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_4" : [
        "ddd62775-3730-4128-8655-17f96ae97535"
      ],
      "Paragraph_3" : [
        "1babc1b0-ad6d-49e7-a540-677bde277f9b"
      ],
      "Paragraph_2" : [
        "d639823a-add8-4ab5-8c0f-1f460b7e886c"
      ]
    },
    "761e17d9-4016-42d3-86a9-92aef0fba110" : {
      "Hotspot_6" : [
        "a9728240-1718-464b-a2dd-56afe2f18758"
      ],
      "Hotspot_1" : [
        "a9728240-1718-464b-a2dd-56afe2f18758"
      ],
      "Paragraph_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_2" : [
        "ddd62775-3730-4128-8655-17f96ae97535"
      ],
      "Paragraph_3" : [
        "1babc1b0-ad6d-49e7-a540-677bde277f9b"
      ],
      "Paragraph_4" : [
        "d639823a-add8-4ab5-8c0f-1f460b7e886c"
      ],
      "Hotspot_5" : [
        "e4a7ac8c-d008-465a-a5ba-dad5ef0f4d6d"
      ]
    },
    "91d52cea-b132-4968-be2f-8c614f78dc4b" : {
      "Hotspot_1" : [
        "a9728240-1718-464b-a2dd-56afe2f18758"
      ],
      "Paragraph_12" : [
        "b3e60a04-98c3-4a42-b91c-e0f5f994cc4d"
      ],
      "Paragraph_14" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_15" : [
        "ddd62775-3730-4128-8655-17f96ae97535"
      ],
      "Paragraph_16" : [
        "1babc1b0-ad6d-49e7-a540-677bde277f9b"
      ],
      "Paragraph_17" : [
        "d639823a-add8-4ab5-8c0f-1f460b7e886c"
      ],
      "Hotspot_10" : [
        "e4a7ac8c-d008-465a-a5ba-dad5ef0f4d6d"
      ]
    },
    "76775d35-8df5-4014-b952-059d98a7145b" : {
      "Hotspot_4" : [
        "02e86551-4e38-4404-8e4f-81367399085d"
      ],
      "Hotspot_2" : [
        "b85dbafa-dce5-4914-9bee-803e3cc20476"
      ],
      "Paragraph_3" : [
        "e4a7ac8c-d008-465a-a5ba-dad5ef0f4d6d"
      ]
    },
    "1babc1b0-ad6d-49e7-a540-677bde277f9b" : {
      "Button_1" : [
        "1babc1b0-ad6d-49e7-a540-677bde277f9b"
      ],
      "Paragraph_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_2" : [
        "ddd62775-3730-4128-8655-17f96ae97535"
      ],
      "Paragraph_3" : [
        "1babc1b0-ad6d-49e7-a540-677bde277f9b"
      ],
      "Paragraph_4" : [
        "d639823a-add8-4ab5-8c0f-1f460b7e886c"
      ],
      "Hotspot_2" : [
        "e4a7ac8c-d008-465a-a5ba-dad5ef0f4d6d"
      ]
    },
    "bd48995b-8bc6-4d41-8fab-7b7e7c5cc426" : {
      "Hotspot_13" : [
        "2d9938d3-2b8b-4744-9266-62aa86841c4d"
      ],
      "Paragraph_8" : [
        "6c461711-eacb-4ed1-b333-9b819cab482e"
      ],
      "Paragraph_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_10" : [
        "ddd62775-3730-4128-8655-17f96ae97535"
      ],
      "Paragraph_11" : [
        "1babc1b0-ad6d-49e7-a540-677bde277f9b"
      ],
      "Paragraph_12" : [
        "d639823a-add8-4ab5-8c0f-1f460b7e886c"
      ],
      "Hotspot_2" : [
        "e4a7ac8c-d008-465a-a5ba-dad5ef0f4d6d"
      ]
    },
    "6c461711-eacb-4ed1-b333-9b819cab482e" : {
      "Paragraph_2" : [
        "bd48995b-8bc6-4d41-8fab-7b7e7c5cc426"
      ],
      "Paragraph_3" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_4" : [
        "ddd62775-3730-4128-8655-17f96ae97535"
      ],
      "Paragraph_5" : [
        "1babc1b0-ad6d-49e7-a540-677bde277f9b"
      ],
      "Paragraph_6" : [
        "d639823a-add8-4ab5-8c0f-1f460b7e886c"
      ],
      "Hotspot_4" : [
        "e4a7ac8c-d008-465a-a5ba-dad5ef0f4d6d"
      ]
    },
    "87a3a7ab-b815-47eb-a4f8-41f692128f10" : {
      "Hotspot_6" : [
        "b85dbafa-dce5-4914-9bee-803e3cc20476"
      ],
      "Hotspot_7" : [
        "b85dbafa-dce5-4914-9bee-803e3cc20476"
      ],
      "Paragraph_9" : [
        "e4a7ac8c-d008-465a-a5ba-dad5ef0f4d6d"
      ]
    },
    "a9728240-1718-464b-a2dd-56afe2f18758" : {
      "Hotspot_11" : [
        "ddd62775-3730-4128-8655-17f96ae97535"
      ],
      "Hotspot_1" : [
        "761e17d9-4016-42d3-86a9-92aef0fba110"
      ],
      "Path_5" : [
        "91d52cea-b132-4968-be2f-8c614f78dc4b"
      ],
      "Path_7" : [
        "91d52cea-b132-4968-be2f-8c614f78dc4b"
      ],
      "Path_8" : [
        "91d52cea-b132-4968-be2f-8c614f78dc4b"
      ],
      "Path_9" : [
        "91d52cea-b132-4968-be2f-8c614f78dc4b"
      ],
      "Path_10" : [
        "91d52cea-b132-4968-be2f-8c614f78dc4b"
      ],
      "Paragraph_11" : [
        "ddd62775-3730-4128-8655-17f96ae97535"
      ],
      "Paragraph_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_2" : [
        "ddd62775-3730-4128-8655-17f96ae97535"
      ],
      "Paragraph_3" : [
        "1babc1b0-ad6d-49e7-a540-677bde277f9b"
      ],
      "Paragraph_4" : [
        "d639823a-add8-4ab5-8c0f-1f460b7e886c"
      ],
      "Hotspot_10" : [
        "e4a7ac8c-d008-465a-a5ba-dad5ef0f4d6d"
      ]
    },
    "2d9938d3-2b8b-4744-9266-62aa86841c4d" : {
      "Hotspot_1" : [
        "02e86551-4e38-4404-8e4f-81367399085d"
      ]
    },
    "b85dbafa-dce5-4914-9bee-803e3cc20476" : {
      "Hotspot_2" : [
        "76775d35-8df5-4014-b952-059d98a7145b"
      ],
      "Hotspot_3" : [
        "87a3a7ab-b815-47eb-a4f8-41f692128f10"
      ],
      "Paragraph_3" : [
        "e4a7ac8c-d008-465a-a5ba-dad5ef0f4d6d"
      ],
      "Paragraph_7" : [
        "e4a7ac8c-d008-465a-a5ba-dad5ef0f4d6d"
      ]
    },
    "7699c6f4-e99e-4163-8b56-5383848d89df" : {
      "Button_1" : [
        "e4a7ac8c-d008-465a-a5ba-dad5ef0f4d6d"
      ]
    },
    "b3e60a04-98c3-4a42-b91c-e0f5f994cc4d" : {
      "Hotspot_2" : [
        "a9728240-1718-464b-a2dd-56afe2f18758"
      ],
      "Paragraph_7" : [
        "91d52cea-b132-4968-be2f-8c614f78dc4b"
      ],
      "Paragraph_8" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_9" : [
        "ddd62775-3730-4128-8655-17f96ae97535"
      ],
      "Paragraph_10" : [
        "1babc1b0-ad6d-49e7-a540-677bde277f9b"
      ],
      "Paragraph_11" : [
        "d639823a-add8-4ab5-8c0f-1f460b7e886c"
      ],
      "Hotspot_9" : [
        "e4a7ac8c-d008-465a-a5ba-dad5ef0f4d6d"
      ]
    },
    "ddd62775-3730-4128-8655-17f96ae97535" : {
      "Hotspot_2" : [
        "a9728240-1718-464b-a2dd-56afe2f18758"
      ],
      "Paragraph_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_2" : [
        "ddd62775-3730-4128-8655-17f96ae97535"
      ],
      "Paragraph_3" : [
        "1babc1b0-ad6d-49e7-a540-677bde277f9b"
      ],
      "Paragraph_4" : [
        "d639823a-add8-4ab5-8c0f-1f460b7e886c"
      ],
      "Hotspot_4" : [
        "e4a7ac8c-d008-465a-a5ba-dad5ef0f4d6d"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Button_2" : [
        "e4a7ac8c-d008-465a-a5ba-dad5ef0f4d6d"
      ],
      "Button_3" : [
        "7699c6f4-e99e-4163-8b56-5383848d89df"
      ]
    },
    "d639823a-add8-4ab5-8c0f-1f460b7e886c" : {
      "Button_1" : [
        "d639823a-add8-4ab5-8c0f-1f460b7e886c"
      ],
      "Paragraph_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_2" : [
        "ddd62775-3730-4128-8655-17f96ae97535"
      ],
      "Paragraph_3" : [
        "1babc1b0-ad6d-49e7-a540-677bde277f9b"
      ],
      "Paragraph_4" : [
        "d639823a-add8-4ab5-8c0f-1f460b7e886c"
      ],
      "Hotspot_2" : [
        "e4a7ac8c-d008-465a-a5ba-dad5ef0f4d6d"
      ]
    },
    "8002115f-7bef-4df3-997f-091229ff38d6" : {
      "Image_4" : [
        "e4a7ac8c-d008-465a-a5ba-dad5ef0f4d6d"
      ],
      "Path_2" : [
        "bd48995b-8bc6-4d41-8fab-7b7e7c5cc426"
      ],
      "Path_4" : [
        "bd48995b-8bc6-4d41-8fab-7b7e7c5cc426"
      ],
      "Path_5" : [
        "bd48995b-8bc6-4d41-8fab-7b7e7c5cc426"
      ],
      "Paragraph_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_2" : [
        "ddd62775-3730-4128-8655-17f96ae97535"
      ],
      "Paragraph_3" : [
        "1babc1b0-ad6d-49e7-a540-677bde277f9b"
      ],
      "Paragraph_4" : [
        "d639823a-add8-4ab5-8c0f-1f460b7e886c"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);